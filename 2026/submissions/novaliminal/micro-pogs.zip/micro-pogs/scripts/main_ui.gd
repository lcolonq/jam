extends CanvasLayer

const TIMER_GRADIENT = preload("uid://683vqrcbtwf8")

@onready var game_timer: Label = $Control/GameTimer
@onready var score_label: Label = $Control/ScoreLabel
@onready var win_label: RichTextLabel = $Control/WinLabel
@onready var lose_label: RichTextLabel = $Control/LoseLabel
@onready var end_background: ColorRect = $Control/EndBackground
@onready var power_meter: ProgressBar = $Control/PowerMeter
@onready var progress_bar: ProgressBar = $Control/BorderPanel/MaskPanel/ProgressBar

@export var power_meter_offset: Vector2 = Vector2(30, -25)

var game_time: float = 30.0
var game_time_current: float = 0.0
var score: int = 0
var score_goal: int = 20
var progress_tween: Tween


func _ready() -> void:
	SignalManager.slammer_charge.connect(_on_slammer_charge)
	SignalManager.slammer_release.connect(_on_slammer_release)
	SignalManager.increase_score.connect(_on_increase_score)
	SignalManager.game_ready.connect(_on_game_ready)


func _on_game_ready() -> void:
	end_background.hide()
	win_label.hide()
	lose_label.hide()
	power_meter.hide()
	score = 0
	game_time_current = game_time
	progress_bar.max_value = score_goal
	progress_bar.value = 0.0
	_on_increase_score(0)


func _process(delta: float) -> void:
	power_meter.value = SignalManager.slam_pow
	power_meter.global_position = \
		get_viewport().get_mouse_position() + power_meter_offset
		
	if not SignalManager.current_game_state == SignalManager.GAME_STATE.PLAYING:
		return
	
	game_time_current -= delta
	if game_time_current <= 0.0:
		game_timer.text = "0"
		SignalManager.current_game_state = SignalManager.GAME_STATE.LOSE
		end_background.show()
		lose_label.show()
		power_meter.hide()
		SignalManager.game_end.emit()
	else:
		game_timer.text = String.num(game_time_current, 1) + "s"
		game_timer.add_theme_color_override("font_color",
			TIMER_GRADIENT.gradient.sample(game_time_current/game_time)
		)


func _on_increase_score(amount: int) -> void:
	score += amount
	score_label.text = "Pog Flips: " + str(score) + "/" + str(score_goal)
	_update_progress_bar(score - amount, score, 0.2)
	
	if not SignalManager.current_game_state == SignalManager.GAME_STATE.PLAYING:
		return
	
	if score >= score_goal:
		SignalManager.current_game_state = SignalManager.GAME_STATE.WIN
		end_background.show()
		win_label.show()
		power_meter.hide()
		SignalManager.game_end.emit()


func _update_progress_bar(from: int, to: int, duration: float) -> void:
	if progress_tween:
		progress_tween.kill()
	progress_tween = create_tween()
	progress_tween.set_ease(Tween.EASE_OUT)
	progress_tween.tween_method(_move_progress_bar, float(from), float(to), duration)


func _move_progress_bar(value: float) -> void:
	progress_bar.value = value


func _on_slammer_charge() -> void:
	power_meter.show()


func _on_slammer_release() -> void:
	power_meter.hide()
