extends Label3D

@onready var animation_player: AnimationPlayer = $AnimationPlayer


var pog_value_text: String :
	set(value):
		pog_value_text = value
		text = pog_value_text


func _ready() -> void:
	text = pog_value_text
	animation_player.play("plus_one")
