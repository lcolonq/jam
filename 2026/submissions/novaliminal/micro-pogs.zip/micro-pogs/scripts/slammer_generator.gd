extends Node3D

const SLAMMER = preload("uid://dfhj4t8n48rj6")
const Slammer = preload("uid://blw4trdts4b0c")

var angular_velocity_max: float = 5.0
var xz_linear_velocity_max: float = 10.0
var y_linear_velocity_min: float = 25.0
var y_linear_velocity_max: float = 50.0
var origin_max: float = 1.0
var charging_slam: bool = false


func _ready() -> void:
	SignalManager.new_slammer.connect(_on_new_slammer)


func _input(event: InputEvent) -> void:
	if SignalManager.current_game_state == SignalManager.GAME_STATE.READY:
		if event.is_action_pressed("generate_slammer"):
			SignalManager.game_start.emit()
	if SignalManager.current_game_state == SignalManager.GAME_STATE.PLAYING:
		if event.is_action_pressed("generate_slammer"):
			charging_slam = true
			SignalManager.slammer_charge.emit()
		if event.is_action_released("generate_slammer"):
			charging_slam = false
			SignalManager.slammer_release.emit()
			_generate_slammer()


func _physics_process(delta: float) -> void:
	if charging_slam:
		SignalManager.slam_pow += delta * 10.0


func _on_new_slammer() -> void:
	_generate_slammer()


func _generate_slammer(new_seed: int = 0) -> void:
	var rng := RandomNumberGenerator.new()
	if new_seed:
		rng.seed = new_seed
	else:
		rng.randomize()
	var new_slammer := SLAMMER.instantiate() as Slammer
	new_slammer.angular_velocity = Vector3(
		rng.randf_range(-angular_velocity_max, angular_velocity_max),
		rng.randf_range(-angular_velocity_max, angular_velocity_max),
		rng.randf_range(-angular_velocity_max, angular_velocity_max))
	new_slammer.linear_velocity = \
		(SignalManager.slam_pos - global_position) * SignalManager.slam_pow
	new_slammer.position.x = rng.randf_range(-origin_max, origin_max)
	new_slammer.position.z = rng.randf_range(-origin_max, origin_max)
	new_slammer.rotation.x = rng.randf_range(deg_to_rad(-180), deg_to_rad(180))
	new_slammer.rotation.y = rng.randf_range(deg_to_rad(-180), deg_to_rad(180))
	new_slammer.rotation.z = rng.randf_range(deg_to_rad(-180), deg_to_rad(180))
	add_child(new_slammer)
	SignalManager.slam_pow = 0.0
