extends Node3D

@onready var plus_pog_label: Label3D = %PlusPogLabel
