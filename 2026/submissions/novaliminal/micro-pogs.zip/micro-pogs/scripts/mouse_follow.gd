extends RayCast3D


# STEWIE_NOTE: Technically, you could offset the ray start a little
# bit along the ray normal, in some cases, to avoid the ray detecting 
# stuff that the camera might be inside of, or that might not be visible 
# due to near plane clipping
@export_flags_3d_render var render_layers: int
@export var ray_length: float = 50
var debug_shape: MeshInstance3D
var debug_immediate_mesh: ImmediateMesh
var debug_bubble: SphereMesh

func _ready() -> void:
	top_level = true
	transform = Transform3D.IDENTITY
	debug_shape = MeshInstance3D.new()
	debug_shape.layers = render_layers
	var debug_mat: StandardMaterial3D = StandardMaterial3D.new()
	debug_mat.albedo_color = Color("#009900")
	debug_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	debug_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	debug_mat.render_priority = 69
	debug_bubble = SphereMesh.new()
	debug_shape.mesh = debug_bubble
	debug_shape.material_override = debug_mat
	debug_shape.top_level = true
	add_child(debug_shape)


func _physics_process(_delta: float) -> void:
	var mouse_pos: Vector2 = get_viewport().get_mouse_position()
	var current_cam: Camera3D = get_viewport().get_camera_3d()
	var cam_origin: Vector3 = current_cam.project_ray_origin(mouse_pos)
	var cam_normal: Vector3 = current_cam.project_ray_normal(mouse_pos)
	global_position = cam_origin
	target_position = cam_normal * ray_length
	force_raycast_update()
	if not is_colliding(): return
	var debug_shape_point := get_collision_point()
	debug_shape.global_position = debug_shape_point
	SignalManager.slam_pos = debug_shape_point
