extends RigidBody3D

@export var pog_texture: Texture
@export var pog_color: Color
@onready var mesh_instance_3d: MeshInstance3D = $MeshInstance3D as MeshInstance3D
@onready var animation_player: AnimationPlayer = $AnimationPlayer as AnimationPlayer

enum SLAMMER_STATE {
	ACTIVE,
	PRE_SLAM
}
var current_slammer_state: SLAMMER_STATE = SLAMMER_STATE.ACTIVE

var time_to_live: float = 1.0
var time_to_live_timer: float = 0.0


func _ready() -> void:
	SignalManager.game_end.connect(_on_game_end)
	var new_mat: ShaderMaterial = ShaderMaterial.new()
	new_mat.shader = preload("uid://8cwi62kfrmw") as Shader
	new_mat.set_shader_parameter("ALBEDO_TEXTURE", pog_texture)
	new_mat.set_shader_parameter("POG_COLOR", pog_color)
	mesh_instance_3d.material_override = new_mat


func slam(slam_target: Vector3, slam_power: float) -> void:
	linear_velocity = slam_target * slam_power
	current_slammer_state = SLAMMER_STATE.ACTIVE


func _physics_process(delta: float) -> void:
	if current_slammer_state == SLAMMER_STATE.PRE_SLAM:
		return
	time_to_live_timer += delta
	var slammer_stable: bool = false
	if linear_velocity.length() < 0.1 and angular_velocity.length() < 0.1:
		slammer_stable = true
	if time_to_live_timer > time_to_live and slammer_stable:
		animation_player.play("fade_out")


func _end_slammer() -> void:
	queue_free()


func _on_game_end() -> void:
	queue_free()
