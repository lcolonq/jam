extends RigidBody3D

@export var pog_texture: Texture
@export var pog_color: Color
@onready var mesh_instance_3d: MeshInstance3D = $MeshInstance3D as MeshInstance3D
@onready var animation_player: AnimationPlayer = $AnimationPlayer
const PLUS_POG_LABEL = preload("uid://dghj8iu2p3e84")

# checks if the pog is upside down for a certain amount of time
var pog_check_limit: float = 3.0
var pog_check_timer: float = 0.0
var pog_lock_timer: float = 1.0
var ending_pog: bool = false
var pog_value: int = 1


func _ready() -> void:
	SignalManager.game_end.connect(_on_game_end)
	var new_mat: ShaderMaterial = ShaderMaterial.new()
	new_mat.shader = preload("uid://8cwi62kfrmw") as Shader
	new_mat.set_shader_parameter("ALBEDO_TEXTURE", pog_texture)
	new_mat.set_shader_parameter("POG_COLOR", pog_color)
	mesh_instance_3d.material_override = new_mat
	lock_pog()


func _physics_process(delta: float) -> void:
	pog_lock_timer -= delta
	if pog_lock_timer < 0.0:
		lock_pog(false)
	pog_check_timer += delta
	if basis.y.y < 0.0:
		pog_check_timer = 0.0
	if pog_check_timer >= pog_check_limit and not ending_pog:
		ending_pog = true
		_end_pog()


func lock_pog(locked: bool = true) -> void:
	axis_lock_angular_x = locked
	axis_lock_angular_z = locked
	axis_lock_angular_y = locked
	axis_lock_linear_x = locked
	axis_lock_linear_z = locked


func _end_pog() -> void:
	SignalManager.increase_score.emit(pog_value)
	animation_player.play("fade_out")
	var new_label: Node3D = PLUS_POG_LABEL.instantiate() as Node3D
	# kinda hacky, but whatevs...
	get_parent().get_parent().add_child(new_label)
	new_label.plus_pog_label.pog_value_text = "+" + str(pog_value)
	new_label.global_position = global_position
	new_label.rotation = Vector3.ZERO


func _on_game_end() -> void:
	queue_free()
