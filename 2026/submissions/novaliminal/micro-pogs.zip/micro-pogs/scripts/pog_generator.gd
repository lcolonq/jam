extends Node3D

const POG = preload("uid://cxq1irt30ys5s")
const Pog = preload("uid://bicwi4dwgbdib")

var pog_spawner_height: float = 0.05

@export var pog_interval: float = 0.1
@export var initial_pogs_min: int = 3
@export var initial_pogs_max: int = 7
var pog_timer: float = 0.0
var pog_limit: int = 200


const PIXEL_AROMANTIC_HEART = preload("uid://bpg3hdfj2mwi1")
const PIXEL_ASEXUAL_HEART = preload("uid://d3ylxccno2jna")
const PIXEL_BISEXUAL_HEART = preload("uid://dr6o3nfosfpbg")
const PIXEL_GAY_MASC_HEART = preload("uid://dr8hmj1ady2vd")
const PIXEL_GENDERFLUID_HEART = preload("uid://rf8tqjvek2qq")
const PIXEL_INTERSEX_HEART = preload("uid://bjfv017ec6b3c")
const PIXEL_LESBIAN_HEART = preload("uid://csrdagpcytvus")
const PIXEL_NONBINARY_HEART = preload("uid://cxb2dvmkh7f2s")
const PIXEL_PANSEXUAL_HEART = preload("uid://b1hyjqaqui5eu")
const PIXEL_POLYAMORY_HEART = preload("uid://crphx0iktj6ew")
const PIXEL_PRIDE_HEART = preload("uid://dhdejhofpm3hq")
const PIXEL_TRANS_HEART = preload("uid://m0dfrvrrfq32")
const PIXEL_TRANS_HEART_VIBES = preload("uid://cr5xta6pdcjfj")
const GLOWHEART_112 = preload("uid://tpvtv25tf7xa")
const PINKHEART_112 = preload("uid://bpq4i470jbgdb")
const SLIME_FRIEND_112 = preload("uid://dcpf7a2e4vgvr")
const SYNTHWAVE_SUN_112 = preload("uid://dyxcdb4opntq5")


var pog_textures: Array[Texture] = [
	GLOWHEART_112,
	PINKHEART_112,
	SLIME_FRIEND_112,
	SYNTHWAVE_SUN_112,
	PIXEL_AROMANTIC_HEART,
	PIXEL_ASEXUAL_HEART,
	PIXEL_BISEXUAL_HEART,
	PIXEL_GAY_MASC_HEART,
	PIXEL_GENDERFLUID_HEART,
	PIXEL_INTERSEX_HEART,
	PIXEL_LESBIAN_HEART,
	PIXEL_NONBINARY_HEART,
	PIXEL_PANSEXUAL_HEART,
	PIXEL_POLYAMORY_HEART,
	PIXEL_PRIDE_HEART,
	PIXEL_TRANS_HEART,
	PIXEL_TRANS_HEART_VIBES,
]


func _ready() -> void:
	SignalManager.new_pog.connect(_on_new_pog)
	SignalManager.game_ready.connect(_on_game_ready)
	position.y = pog_spawner_height


func _on_game_ready() -> void:
	for i in randi_range(initial_pogs_min, initial_pogs_max):
		_generate_pog(pog_textures.pick_random(), _random_color())
	await get_tree().create_timer(1.0).timeout
	for pogger: Pog in get_children():
		pogger.lock_pog(false)


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("generate_pog"):
		_generate_pog(pog_textures.pick_random(), _random_color())


func _physics_process(delta: float) -> void:
	pog_timer += delta
	if pog_timer >= pog_interval:
		pog_timer -= pog_interval


func _get_highest_pog_height() -> float:
	var max_height: float = 0.1
	for pogger: Pog in get_children():
		if pogger.position.y > max_height:
			max_height = pogger.position.y
	return max_height


func _generate_pog(pog_texture: Texture, pog_color: Color) -> void:
	var new_pog := POG.instantiate() as Pog
	if get_child_count():
		new_pog.position.y = _get_highest_pog_height() + 0.1
	new_pog.lock_pog()
	new_pog.pog_texture = pog_texture
	new_pog.pog_color = pog_color
	add_child(new_pog)
	if get_child_count() > pog_limit:
		get_child(0).call_deferred("queue_free")
		remove_child(get_child(0))
	new_pog.sleeping = true


func _random_color() -> Color:
	return Color(randf(), randf(), randf()).lightened(0.2)


func _on_new_pog(new_texture: Texture) -> void:
	_generate_pog(new_texture, _random_color())
