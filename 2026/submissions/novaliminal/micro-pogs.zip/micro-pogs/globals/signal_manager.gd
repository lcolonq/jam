extends Node

@warning_ignore("unused_signal")
signal new_pog(new_texture: Texture)
@warning_ignore("unused_signal")
signal new_slammer()
@warning_ignore("unused_signal")
signal increase_score(amount: int)
signal game_ready()
signal game_start()
@warning_ignore("unused_signal")
signal game_end()

@warning_ignore("unused_signal")
signal slammer_charge()
@warning_ignore("unused_signal")
signal slammer_release()

# kinda squimshing a GameManager in here... but it's okay :3
enum GAME_STATE {
	READY,
	PLAYING,
	WIN,
	LOSE
}
var current_game_state: GAME_STATE = GAME_STATE.READY

var end_game_timer: float = 0.0
var end_game_pause_amount: float = 6.0
var slam_pos: Vector3 = Vector3.ZERO
var slam_pow: float = 0.0


func _ready() -> void:
	game_ready.connect(_on_game_ready)
	game_start.connect(_on_game_start)


func _process(delta: float) -> void:
	match current_game_state:
		GAME_STATE.READY:
			_handle_jam_start()
		GAME_STATE.PLAYING:
			return
		GAME_STATE.WIN, GAME_STATE.LOSE:
			end_game_timer += delta
			if end_game_timer >= end_game_pause_amount:
				_end_game()


func _handle_jam_start() -> void:
	if not OS.get_name() == "Web":
		game_start.emit()
	var lcolonqJamStart = JavaScriptBridge.eval("window.lcolonqJamStart || -1.0")
	if not lcolonqJamStart:
		return
	if lcolonqJamStart > 0.0:
		JavaScriptBridge.eval("window.parent.postMessage({op: \"started\", verb: \"slam!\"});")
		game_start.emit()


func _on_game_ready() -> void:
	slam_pow = 0.0
	current_game_state = GAME_STATE.READY
	if OS.get_name() == "Web":
		JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});")


func _on_game_start() -> void:
	current_game_state = GAME_STATE.PLAYING


func _end_game() -> void:
	if OS.get_name() == "Web":
		if current_game_state == GAME_STATE.WIN:
			JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")
		if current_game_state == GAME_STATE.LOSE:
			JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")
	# restart the game
	end_game_timer = 0.0
	game_ready.emit()
