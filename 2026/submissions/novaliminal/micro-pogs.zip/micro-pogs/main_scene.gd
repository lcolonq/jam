extends Node3D


func _ready() -> void:
	SignalManager.game_ready.emit()


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("quit_game") and not OS.get_name() == "Web":
		get_tree().quit()
