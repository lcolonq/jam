extends Sprite2D

var center := Vector2.ZERO
var angle := 0.
var ang_speed := 1.5
var danger_zone = false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	center = position
	$CircleExpiryTimer.wait_time = randf_range(1,3)
	$CircleExpiryTimer.start()
	var roll = randi_range(1,2)
	if roll == 1:
		ang_speed = -1.5
	pass # Replace with function body.

func animate_death(time_left):
	lerp(1, 10, 0.1)
	var shake = 2
	var shake_duration = 0.1
	var shake_count = 10
	var t = create_tween()
	for i in shake_count:
		t.tween_property(self, "position", position + Vector2(randi_range(-shake, shake), randi_range(-shake, shake)), shake_duration)
	await t.finished
	GameState.health -= 100
	print("health: %d " % GameState.health)
	queue_free()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if $CircleExpiryTimer.time_left < 0.5 and not danger_zone:
		animate_death($CircleExpiryTimer.time_left)
		danger_zone = true
		
	angle += ang_speed * delta
	position =  center + Vector2(cos(angle), sin(angle)) * 10
	
	
	pass
