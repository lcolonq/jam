extends Node2D

@onready var circle_node = get_child(0).duplicate()
@onready var timer = get_node("CircleTimer")
var game_state = "running"

func new_circle():
	var temp_circle = circle_node.duplicate()
	var radius = temp_circle.get_node("CircleToClick/CircleShape").shape.radius
	#radius + overlay + hovering
	var padding_x = radius + 4 + 10
	var padding_top = radius + 13 + 10
	var padding_bottom = radius + 14 + 10
	
	temp_circle.position = Vector2(
		randf_range(radius + padding_x, 240 - padding_x),
		 randf_range(radius + padding_top, 160 - padding_bottom)
	)
	temp_circle.visible = true
	add_child(temp_circle)
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	
func tell_harness():
	if game_state == "win":
		await get_tree().create_timer(3).timeout
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")
		
	elif game_state == "loss":
		await get_tree().create_timer(3).timeout
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")
		

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if GameState.game_score >= 20 and game_state == "running":
		game_state = "win"
		tell_harness()
		
	if GameState.health <= 0 and game_state == "running":
		game_state = "loss"
		tell_harness()
	pass

func _on_timer_timeout() -> void:
	if game_state == "running":
		new_circle()
		timer.wait_time = randf_range(0.3, 0.5)
	else:
		if game_state == "win":
			get_node("/root/Main/Overlay/ClearMsgSprite").visible = true
		elif game_state == "loss":
			get_node("/root/Main/Overlay/GameOverSprite").visible = true
		
		for i in get_children():
			
			if is_instance_valid(i):
				if not i.is_queued_for_deletion() and i is Node2D:
						var t = create_tween()
						t.tween_property(i, "scale", Vector2(0.0,0.0), 1).set_trans(Tween.TRANS_CIRC)
						await get_tree().create_timer(0.1).timeout
						
		
		
	
		
		
		
	pass # Replace with function body.
