TODO:
some sound
better overlay (solid color kinda looks weird on the wario ware thingy)

DONE:

use verb
implement difficulty (maybe less health if the difficulty is higher)
implement losing
make it so there's a pause before signaling the harness for game end

BUGS:
fix input (only pop foreground bubble)
