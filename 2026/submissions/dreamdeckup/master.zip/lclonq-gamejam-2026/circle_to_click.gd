extends Area2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	pass


func _on_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and get_parent().get_parent().game_state == "running":
			GameState.game_score += 1
			get_parent().queue_free()
			

	pass # Replace with function body.


func _on_mouse_entered() -> void:
	return
	if self not in GameState.bubble_list:
		GameState.bubble_list.append(self)
	pass # Replace with function body.
	
func _on_mouse_exited() -> void:
	return
	if self in GameState.bubble_list:
		for i in GameState.bubble_list.size():
			if self == GameState.bubble_list[i]:
				GameState.bubble_list.remove_at(i)
	pass # Replace with function body.
