extends Node2D

signal game_starts
@onready var game_node = get_node("/root/Main/Game")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	game_starts.connect(game_node._on_game_starts)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_start_game_timer_timeout() -> void:
	
	var t := create_tween()
	t.tween_property($StartMsgSprite, "scale", Vector2(0.2, 0.2), 0.5)
	
	await t.finished
	$StartMsgSprite.queue_free()
	
	game_starts.emit()
	pass # Replace with function body.
