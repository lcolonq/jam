extends Sprite2D

var orig_scale : Vector2
var was_above_five = false
var was_above_ten = false
var was_above_fifteen = false
var was_above_twenty = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	orig_scale = scale
	pass # Replace with function body.

func pop_out_gauge():
	var t = create_tween()
	t.tween_property(self, "scale", orig_scale*1.3, 0.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t.tween_property(self, "scale", orig_scale , 0.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if GameState.game_score >= 5 and GameState.game_score < 10:
		if not was_above_five:
			pop_out_gauge()
			was_above_five = true
			region_rect.position.y = 6
	elif GameState.game_score >= 10 and GameState.game_score < 15:
		if not was_above_ten:
			pop_out_gauge()
			was_above_ten = true
			region_rect.position.y = 12
	elif GameState.game_score >= 15 and GameState.game_score < 20:
		if not was_above_fifteen:
			pop_out_gauge()
			was_above_fifteen = true
			region_rect.position.y = 18
	elif GameState.game_score >= 20:
		if not was_above_twenty:
			pop_out_gauge()
			was_above_twenty = true
			region_rect.position.y = 24
	pass
