extends Node2D
var started = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});")
	
	pass # Replace with function body.

func _on_game_starts():
	$CirclesClicking/CircleTimer.start()
	$CirclesClicking.new_circle()
	print("game started")
	
	pass
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if !started && JavaScriptBridge.eval("window.lcolonqJamStart || -1.0") > 0.0:
		started = true
		JavaScriptBridge.eval("window.parent.postMessage({op: \"started\", verb: \"pop!\"});")
		var diff = JavaScriptBridge.eval("window.lcolonqJamStart")
		GameState.difficulty = diff
		
		print("Starting bubble popper at difficulty: %d " % diff)
		
		#so that it starts at 100% health then tapers of to 1/2
		var health_factor = 1/(diff+1) + 0.5
		GameState.health = health_factor * GameState.health
		print("Starting health value: %d " % GameState.health)
		get_node("/root/Main/Overlay/StartMsg/StartGameTimer").start()
	pass
