extends Node2D

signal delete_fuel
signal set_rod_range(val: int)
signal set_water_flow_range(val: int)
signal update_power_meter #water: int, rod: int
signal emit_set_rod
signal emit_set_water

var water_slider: HSlider
var water_flow_value = 0
var current_water_flow_value: int
var water_buttons

var rod_slider: HSlider
var rod_range_value = 0
var current_rod_value: int
var rod_buttons

var delta_offset = 0
var started = false

func _ready() -> void:
	JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});")
	rod_range_value = randi() % 100
	water_flow_value = 100 - rod_range_value

	set_rod_range.emit(rod_range_value)
	set_water_flow_range.emit(water_flow_value)
	
	rod_slider = get_node("ControlRodSlider/HSlider")
	rod_buttons = get_node("ControlRodSlider/SliderIndicatorRod")
	rod_slider.value_changed.connect(on_rod_slider_change)
	
	water_slider = get_node("WaterFlowSlider/HSlider")
	water_buttons = get_node("WaterFlowSlider/SliderIndicatorWater")
	water_slider.value_changed.connect(on_water_slider_change)

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if !event.pressed:
			delete_fuel.emit()

func on_rod_slider_change(val: int) -> void:
	if not $AudioStreamPlayer.playing:
		$AudioStreamPlayer.play()
	print("Rod Slider Value: %s, needed: %s" % [val, rod_range_value])
	current_rod_value = val
	var is_correct_range = check_correct_range(val, rod_range_value)
	if is_correct_range:
		rod_slider.editable = false
		rod_buttons.set_green()
		emit_set_rod.emit()
	
func on_water_slider_change(val: int) -> void:
	if not $AudioStreamPlayer.playing:
		$AudioStreamPlayer.play()
	print("Water Slider Value: %s, needed: %s" % [val, water_flow_value])
	current_water_flow_value = val
	var is_correct_range = check_correct_range(val, water_flow_value)
	if is_correct_range:
		water_slider.editable = false
		water_buttons.set_green()
		emit_set_water.emit()

func _process(_delta: float) -> void:
	if !started && JavaScriptBridge.eval("window.lcolonqJamStart || -1.0") > 0.0:
		started = true
		JavaScriptBridge.eval("window.parent.postMessage({op: \"started\"});")
	if (rod_slider.value > 0 or water_slider.value > 0):
		update_power_meter.emit()
	
func check_correct_range(val: int, range_mark: int) -> bool:
	var range_min = range_mark - 5
	var range_max = range_mark + 5
	
	if val > range_mark and val < range_max:
		return true
	elif val < range_mark and val > range_min:
		return true

	return false

# lose game here
func _on_power_meter_lost_game() -> void:
	$LoseSprite.visible = true
	started = false
	JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")

# win game here
func _on_power_meter_win_game() -> void:
	$WinSprite.visible = true
	started = false
	JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")
