extends Node2D

class_name PowerSlider

var min_green = 76
var max_green = 91
var min_red = 92
var rod_set = false
var water_set = false
var lost = false

var power_meter: HSlider

signal lost_game
signal win_game

func _ready() -> void:
	power_meter = get_node("PowerMeter/PowerSlider")

func _process(delta: float) -> void:
	if power_meter.value >= 92 and lost != true:
		print('lost game')
		lost_game.emit()
		lost = true

func _on_main_update_power_meter() -> void:
	if rod_set and water_set and power_meter.value < 91 and power_meter.value > 81:
		win_game.emit()
	else:
		power_meter.value = power_meter.value + 0.1

func _on_main_emit_set_rod() -> void:
	rod_set = true

func _on_main_emit_set_water() -> void:
	water_set = true
