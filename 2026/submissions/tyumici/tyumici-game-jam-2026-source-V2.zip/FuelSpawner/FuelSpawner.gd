extends Area2D

class_name FuelSpawner

@export var fuel_rod_scene: PackedScene = preload("res://FuelRod/FuelRod.tscn")

var is_dragging = false
var fuel_rod: Node2D = null

func _on_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			is_dragging = true
			fuel_rod = fuel_rod_scene.instantiate()
			# Set the spawned sprite's position to where the mouse clicked
			fuel_rod.global_position = get_global_mouse_position()
			get_tree().root.add_child(fuel_rod)
			$AudioStreamPlayer.play()

func _process(delta):
	if is_dragging and is_instance_valid(fuel_rod):
		fuel_rod.global_position = get_global_mouse_position()

func _on_main_delete_fuel() -> void:
	if is_instance_valid(fuel_rod):
		fuel_rod.queue_free()
