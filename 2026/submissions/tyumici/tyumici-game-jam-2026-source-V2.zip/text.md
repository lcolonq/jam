Math to get slider values

- Update power slider position
- audio
- movement on the reactor
- green on reactor circles when entered by rod
- disable rod dispenser on reactor fueled
