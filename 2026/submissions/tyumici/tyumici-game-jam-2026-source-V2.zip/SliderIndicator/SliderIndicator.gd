extends Node

var green_button: Sprite2D
var red_button: Sprite2D

func _ready() -> void:
	green_button = get_node("Green")
	red_button = get_node("Red")
	
	red_button.modulate = Color(4,4,4)

func set_green() -> void:
	red_button.modulate = Color(1,1,1)
	green_button.modulate = Color(4,4,4)
