extends Control

class_name WaterFlowSlider

var needed_slider_value = 0

#@onready var water_flow_slider = $WaterFlowSlider

func _on_reactor_unlock_controls() -> void:
	var slider: HSlider = get_node('HSlider')
	slider.editable = true

func _on_main_set_water_flow_range(val: int) -> void:
	needed_slider_value = val
	print("Got water slider value", val)
