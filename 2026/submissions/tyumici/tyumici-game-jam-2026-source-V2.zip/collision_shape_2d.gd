extends CollisionShape2D
var mouse_offset
signal fuel_dispense(release)

func _on_fuel_drop_area_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.is_pressed():
			fuel_dispense.emit(true)
			print("fuel click")
		if event.is_released():
			fuel_dispense.emit(false)
			print("fuel click release")
