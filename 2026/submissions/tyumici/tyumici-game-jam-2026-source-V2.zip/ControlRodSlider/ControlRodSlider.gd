extends Control

class_name ControlRodSlider

var needed_slider_value = 0

#@onready var control_rod_slider = $ControlRodSlider

func _on_reactor_unlock_controls() -> void:
	var slider: HSlider = get_node('HSlider')
	slider.editable = true

func _on_main_set_rod_range(val: int) -> void:
	needed_slider_value = val
	print("Got rod slider value", val)
