extends Area2D

class_name Reactor

signal unlock_controls

func _on_area_entered(area: Area2D) -> void:
	area.queue_free()
	unlock_controls.emit()
