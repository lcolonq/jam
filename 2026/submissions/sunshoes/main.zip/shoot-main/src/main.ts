import { Game } from "./custom/game";

declare global {
  interface Window {
    enemyDirection: number;
  }
  interface Window {
    restart: (arg: number) => void;
  }
  interface Window {
    triggerRestart: (arg: number) => void;
  }
}

(async () => {
  const game = new Game();

  await game.preload();
  await game.initialize();
  game.listen();
  const app = game.app;

  window.restart = () => {
    game.restart();
  };
  window.triggerRestart = () => {
    game.triggerRestart();
  };

  app.ticker.add((time) => {
    // * Delta is 1 if running at 100% performance *
    // * Creates frame-independent transformation *
    game.update(time);
  });
})();
