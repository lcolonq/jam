import { Sprite, Text, Ticker } from "pixi.js";
import { Game } from "./game";

export class UI {
  public font: string;
  public difficulty: number;
  public game: Game;
  public currentPlayerLives: number;
  public updatePlayerLives: boolean = true;
  public updateEnemyLives: boolean = true;
  public playerLives: Array<Sprite>;
  public enemyLives: Array<Sprite>;
  public outcome: Text | null | undefined = null;

  constructor(difficulty: number, game: Game) {
    this.font = "";
    this.difficulty = difficulty;
    this.game = game;
    this.currentPlayerLives = 3;
    this.playerLives = [];
    this.enemyLives = [];
  }

  /**
   * render
   */
  public render() {
    if (this.updatePlayerLives) {
      // console.log(`rendering plives ${this.game.playerLives} - ${this.game.player.health}`);
      this.drawLives(this.game.playerLives);
      this.updatePlayerLives = false;
      this.drawEnemyLives();
    }
  }

  public drawLives(totalLives: number) {
    let livesDrawn = 0;

    while (livesDrawn < totalLives) {
      const life = Sprite.from("life");
      life.anchor = 0.5;
      life.x = 10 + 15 * livesDrawn;
      life.y = 10;
      life.width = 12.5;
      life.height = 12.5;
      life.label = `life${livesDrawn + 1}`;
      this.playerLives.push(life);
      this.game.app.stage.addChild(life);

      livesDrawn++;
    }
  }

  /**
   * removeLife
   */
  public removeLife() {
    const playerLife1 = this.game.app.stage.getChildByLabel("life1");
    const playerLife2 = this.game.app.stage.getChildByLabel("life2");
    const playerLife3 = this.game.app.stage.getChildByLabel("life3");

    if (playerLife3 !== null && !playerLife3.destroyed) {
      playerLife3.destroy();
      // const hit = sound.play("pain_jack_02.wav");
      // hit.play({ volume: 1 });
    } else if (playerLife2 !== null && !playerLife2.destroyed) {
      playerLife2.destroy();
      // const hit = sound.play("pain_jack_03.wav");
      // hit.play({ volume: 1 });
    } else if (playerLife1 !== null) {
      // const hit = sound.play("pain_jack_01.wav");
      // hit.play({ volume: 1 });
      playerLife1.destroy();
    }
  }

  // TODO remove from enemyLives
  public removeEnemyLife() {
    const enemyLife1 = this.game.app.stage.getChildByLabel("enemyLife1");
    const enemyLife2 = this.game.app.stage.getChildByLabel("enemyLife2");
    const enemyLife3 = this.game.app.stage.getChildByLabel("enemyLife3");

    if (enemyLife3 !== null && !enemyLife3.destroyed) {
      enemyLife3.destroy();
    } else if (enemyLife2 !== null && !enemyLife2.destroyed) {
      enemyLife2.destroy();
    } else if (enemyLife1 !== null) {
      enemyLife1.destroy();
    }
  }

  private drawEnemyLives() {
    let livesDrawn = 0;

    while (livesDrawn < 3) {
      const enemyLife = Sprite.from("wave");
      enemyLife.anchor = 0.5;
      enemyLife.x = this.game.app.screen.width - (10 + livesDrawn * 15);
      enemyLife.y = 10;
      enemyLife.width = 12.5;
      enemyLife.height = 12.5;
      enemyLife.label = `enemyLife${livesDrawn + 1}`;
      this.enemyLives.push(enemyLife);
      this.game.app.stage.addChild(enemyLife);

      livesDrawn++;
    }
  }

  /**
   * shakeLives - TODO only last life
   */
  public shakeLives(time: Ticker) {
    // console.log('shake?')
    if (this.game.framesRendered % 30 == 0) {
      const remainingLives = this.playerLives.filter((life) => {
        return !life.destroyed;
      });
      this.playerLives.forEach((life) => {
        if (remainingLives.length == 1) {
          // console.log('shakingp')
          if (life.rotation == 0) {
            life.rotation = 0.5 * 1 * time.deltaTime;
          } else if (life.rotation > 0) {
            life.rotation = 0.5 * -1 * time.deltaTime;
          } else if (life.rotation < 0) {
            life.rotation = 0.5 * 1 * time.deltaTime;
          }
        }
      });

      // if enemy is on their last life
      const destroyedLives = this.enemyLives.filter((life) => {
        return life.destroyed;
      }).length;
      this.enemyLives.forEach((life) => {
        if (
          destroyedLives === 2 &&
          !life.destroyed &&
          life.label === "enemyLife1"
        ) {
          // console.log('shakinge')
          if (life.y == 10) {
            life.y = life.y - 2 * time.deltaTime;
          } else if (life.y > 10) {
            life.y = life.y - 2 * time.deltaTime;
          } else if (life.y < 10) {
            life.y = life.y + 2 * time.deltaTime;
          }
        }
      });
    }
  }

  public renderOutcome(text: string, x: number, y: number) {
    if (!this.game.app.stage.getChildByLabel("outcome")) {
      const outcomeText = new Text({
        text: text,
        style: {
          fill: "#ffffff",
          fontSize: 36,
          fontFamily: "silkscreen",
        },
        anchor: 0.5,
      });
      outcomeText.x = x;
      outcomeText.y = y;
      outcomeText.label = "outcome";
      this.game.app.stage.addChild(outcomeText);
      return outcomeText;
    }
  }

  /**
   * update
   */
  public update(time: Ticker) {
    this.shakeLives(time);
  }
}
