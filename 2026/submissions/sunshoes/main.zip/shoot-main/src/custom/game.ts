import { Application, Assets, Sprite, Ticker } from "pixi.js";
import { Sound, sound } from "@pixi/sound";
import { UI } from "./ui";
import { Player } from "./player";
import { Enemy } from "./enemy";
import { Entity } from "./entity";

const SCREEN_WIDTH = 240;
const SCREEN_HEIGHT = 160;

export class Game {
  public app: Application;
  public ready: boolean = false;
  public width: number = SCREEN_WIDTH;
  public height: number = SCREEN_HEIGHT;
  public difficulty: number = 0;
  public playerLives: number = 3;
  public playerKills: number = 0;
  public playerDamageTaken: number = 0;
  public music: Sound;
  public player: Player;
  public ui: UI;
  public state: string = "loading";
  public enemies: Array<Enemy> = [];
  public framesRendered: number;

  constructor() {
    this.app = new Application();
    this.music = Sound.from({
      url: "assets/sounds/bgm.wav",
      preload: true,
      loop: true,
      volume: 0.25,
    });
    // TODO this needs to happen after difficulty is set
    this.ui = new UI(this.difficulty, this);
    this.framesRendered = 0;
    this.player = new Player(3, this);
  }

  public listen() {
    window.addEventListener("message", (ev) => {
      switch (ev.data.op) {
        case "start":
          if (ev.data.difficulty !== undefined && ev.data.difficulty !== null) {
            this.difficulty = ev.data.difficulty;
            // TODO update game settings
          }
          // TODO handle restart
          this.restart();
          window.parent.postMessage({ op: "started", verb: "shoot!" });
          break;
        default:
          console.log(`shoot! - received unknown event: ${ev}`);
          break;
      }
    });
    this.ready = true;
    this.music.play();
    window.parent.postMessage({ op: "ready" });
  }

  public async preload() {
    const assets = [
      { alias: "background", src: "/assets/sprites/bg.png" },
      { alias: "player", src: "/assets/sprites/player.png" },
      { alias: "bullet1", src: "/assets/sprites/bullet1.png" },
      { alias: "bullet2", src: "/assets/sprites/bullet2.png" },
      { alias: "bullet3", src: "/assets/sprites/bullet3.png" },
      { alias: "enemy1", src: "/assets/sprites/enemy1.png" },
      { alias: "enemy2", src: "/assets/sprites/enemy2.png" },
      { alias: "enemy3", src: "/assets/sprites/enemy3.png" },
      { alias: "life", src: "/assets/sprites/mrgreen.png" },
      { alias: "wave", src: "/assets/sprites/mrred.png" },
      { alias: "explosion", src: "/assets/animations/explosion.json" },
      {
        alias: "silkscreen",
        src: "/assets/ui/silkscreen_regular.ttf",
        data: { family: "silkscreen" },
      },
      {
        alias: "bungeespice",
        src: "/assets/ui/bungeespice.ttf",
        data: { family: "bungeespice" },
      },
    ];

    sound.add("bgm", "/assets/sounds/bgm.wav");
    sound.add("shoot", "/assets/sounds/shoot.wav");
    sound.add("shoot1", "/assets/sounds/shoot1.wav");
    sound.add("enemyShoot", "/assets/sounds/enemyShoot.wav");
    sound.add("enemyShoot1", "/assets/sounds/enemyShoot1.wav");
    sound.add("hit", "/assets/sounds/hit.wav");
    sound.add("success", "/assets/sounds/success.wav");
    sound.add("failure", "/assets/sounds/failure.wav");
    sound.add("explosion2", "/assets/sounds/explosion2.wav");
    sound.add("player_hit_01", "/assets/sounds/pain_jack_01.wav");
    sound.add("player_hit_02", "/assets/sounds/pain_jack_02.wav");
    sound.add("player_hit_03", "/assets/sounds/pain_jack_03.wav");
    sound.add("player_death_1", "/assets/sounds/death_jack_01.wav");
    sound.add("player_death_2", "/assets/sounds/death_jack_02.wav");
    sound.disableAutoPause = true;
    await Assets.load(assets);
  }

  private setup() {
    // this.ready = true;
    // if (this.player.texture == null || this.player.sprite.texture.label == "EMPTY")
    if (
      this.player.sprite.texture == null ||
      this.player.sprite.texture.label === "EMPTY"
    ) {
      this.player = new Player(this.playerLives, this);
      this.player.spawn();
    }
    // console.log(this.player.sprite.texture.label)

    this.drawUI();

    // console.log(this.player.sprite)
    this.app.stage.onclick = () => {
      if (!this.player.sprite.destroyed) this.player.shoot();
    };
  }

  // rename to initialize
  public async initialize() {
    await this.app.init({
      width: this.width,
      height: this.height,
      background: "#1e1e1f",
    });

    document.getElementById("container")!.appendChild(this.app.canvas);
    const background = Sprite.from("background");
    this.app.stage.addChild(background);

    this.app.stage.interactive = true;
    this.app.renderer.events.cursorStyles.default = "none";
    this.setup();
    this.state = "playing";
  }

  /**
   * drawUI - :3
   */
  public drawUI() {
    if (this.ui.outcome !== null && this.ui.outcome !== undefined) {
      // console.log("destroy outcome")
      this.ui.outcome.destroy();
    }
    this.ui.render();
  }

  /**
   * removeLife
   */
  public removeLife(entity: Enemy | Player | Entity) {
    if (entity instanceof Player) {
      this.ui.removeLife();
    } else if (entity instanceof Enemy) {
      // console.log("removing enemy life")
      this.ui.removeEnemyLife();
      this.playerKills++;
    }
  }

  public update(time: Ticker) {
    this.framesRendered += 1;
    // console.log(this.framesRendered);
    this.ui.update(time);
    this.player.update(time);

    if (this.enemies.length > 0) {
      this.enemies.forEach((enemy) => {
        enemy.update(time);
      });
    } else if (this.playerKills < 3) {
      const enemy = new Enemy(this.playerKills + 1, this);
      this.enemies.push(enemy);
    }

    if (this.playerKills === 3 && this.state !== "ended") {
      // console.log("win")
      this.end(true);
    } else if (
      this.playerDamageTaken === this.playerLives &&
      this.state !== "ended"
    ) {
      // console.log("lose")
      // this.end(false);
    }
  }

  public end(win: boolean) {
    this.ready = false;
    const x = this.width / 2;
    const y = this.height / 2;
    const text = win ? "YOU WIN!" : "YOU LOSE!";
    const alias = win ? "success" : "failure";

    if (!sound.find(alias).isPlaying && this.state !== "ended") {
      this.ui.outcome = this.ui.renderOutcome(text, x, y);
      this.app.stage.onclick = null;
      sound.stopAll();
      this.music.stop();
      this.state = "ended";
      // console.log("end called")
      setTimeout(() => {
        sound.play(alias, {
          volume: 0.25,
          complete: () => {
            // console.log(`rendering plives ${this.playerLives} - ${this.player.health}`);
            // isn't clearing in harness
            while (this.playerKills > 0) {
              this.ui.removeEnemyLife();
              this.playerKills--;
            }
            while (this.playerLives > 0) {
              this.ui.removeLife();
              this.playerLives--;
            }
            this.app.stop();
            window.parent.postMessage({ op: "done", win: win });
          },
        });
      }, 500);
    }

    // setTimeout(() => {
    //   // this.ui
    // }, 3000);
  }

  /**
   * restart
   * - music
   * - ui (outcome, lives)
   * - game (interal lives, waves, enemies)
   * - bullets
   */
  public restart() {
    this.music.stop();
    // console.log(sound.find("bgm").instances.length)
    sound.stopAll();
    this.state = "loading";
    this.player.bullets.forEach((b) => {
      if (!b.sprite.destroyed) {
        b.sprite.destroy();
      }
    });
    this.enemies.forEach((e) => {
      if (!e.sprite.destroyed) {
        e.sprite.destroy();
      }
    });
    this.enemies = [];

    this.teardown();
    while (this.playerKills > 0) {
      this.ui.removeEnemyLife();
      this.playerKills--;
    }
    while (this.playerLives > 0) {
      this.ui.removeLife();
      this.playerLives--;
    }
    // teardown all objects onscreen (except bg & music)
    // reset properties
    this.playerLives = 3; // based on difficulty
    this.playerKills = 0;
    this.playerDamageTaken = 0;
    this.app.stage.removeChild(this.player.sprite);
    this.player.sprite.destroy();

    this.ui = new UI(this.difficulty, this);
    this.ui.updatePlayerLives = true;
    this.setup();
    this.listen(); // starts music
    this.app.start();
    // console.log("hi")
    // console.log(`hp: ${this.player.health}, dt: ${this.playerDamageTaken}, pk: ${this.playerKills}`)
    // other stuff
  }

  public teardown() {
    // console.log('teardown')
    if (this.ui.outcome) {
      // console.log('tearing down~')
      // console.log(this.ui.outcome)
      // console.log(this.ui.outcome.destroyed)
      // console.log(this.app.stage.getChildByLabel("outcome"))
      // console.log(this.app.stage.getChildByLabel("outcome").destroyed)
      this.app.stage.removeChild(this.ui.outcome);
      this.ui.outcome?.destroy();
      this.app.stage.getChildByLabel("outcome")?.destroy();
      // console.log(this.ui.outcome.destroyed)
      // console.log(this.app.stage.getChildrenByLabel("outcome"))
      // console.log(this.app.stage.getChildByLabel("outcome"))
      // console.log(this.app.stage.getChildByLabel("outcome")?.destroyed)
    }

    const outcome = this.app.stage.getChildByLabel("outcome");
    if (outcome !== null) outcome.destroy();
    // console.log(this.app.stage.getChildrenByLabel("outcome").length)
  }

  public triggerRestart(difficulty: number = 10) {
    window.postMessage({ op: "start", difficulty: difficulty });
  }
}
