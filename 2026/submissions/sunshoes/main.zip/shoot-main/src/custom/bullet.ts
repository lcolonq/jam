import { Sprite, Ticker } from "pixi.js";
import { sound } from "@pixi/sound";
import { Game } from "./game";
import { Entity } from "./entity";

interface BulletInfo {
  texture: string;
  behavior: string;
  speed: number;
  sound: string;
}

export class Bullet {
  public type: number;
  public texture: string;
  public sound: string;
  public speed: number;
  public yDirection: number;
  public behavior: string;
  public sprite: Sprite;
  public entity: Entity;
  private stats: BulletInfo;
  private game: Game;
  private scattered: boolean = false;
  private scatterSpeed: number = 0.25; // scale w/ difficulty

  constructor(
    entity: Entity,
    type: number,
    yDirection: number,
    x: number,
    y: number,
  ) {
    this.stats = this.getStats(type) as BulletInfo;
    this.game = entity.game;
    this.entity = entity;
    this.type = type;
    this.texture = this.stats.texture;
    this.behavior = this.stats.behavior;
    this.speed = this.stats.speed;
    this.sound = this.stats.sound;
    this.yDirection = yDirection;
    this.sprite = this.spawn(x, y);
    this.scatterSpeed = 0.25;
  }

  /**
   * spawn
   */
  public spawn(x: number, y: number) {
    const sprite = Sprite.from(this.texture);
    sprite.x = x;
    sprite.y = y;
    sprite.anchor.set(0.5);
    sprite.scale.set(0.075);
    this.game.app.stage.addChild(sprite);

    sound.play(this.sound, { volume: 0.45 });
    return sprite;
  }

  /**
   *
   */
  public update(time: Ticker) {
    if (this.sprite.destroyed) {
      this.entity.bullets = this.entity.bullets.filter((bullet) => {
        return !bullet.sprite.destroyed;
      });
      return;
    }
    const coords = this.sprite.getBounds();
    if (
      coords.y < -(this.sprite.height + 5) ||
      coords.y > this.game.app.screen.height + this.sprite.height
    ) {
      this.sprite.destroy();
      this.entity.bullets = this.entity.bullets.filter((bullet) => {
        return !bullet.sprite.destroyed;
      });
    } else {
      switch (this.type) {
        case 1:
          if (this.entity.constructor.name == "Enemy") {
            console.log(this.entity.constructor.name);
            this.sprite.tint = "#ff1362";
          }
          break;
        case 2:
          this.sprite.width += 0.2 * time.deltaTime;
          this.sprite.height += 0.2 * time.deltaTime;
          break;
        case 3:
          if (
            this.sprite.y > this.game.app.screen.height / 2 - 20 &&
            !this.scattered &&
            this.sprite.label !== "left" &&
            this.sprite.label !== "right"
          ) {
            // console.log(`scatter ${this.sprite.y} - ${this.game.app.screen.height/2}`);
            this.scatter(this);
          }
          this.sprite.rotation += 0.5 * time.deltaTime;
          break;
        default:
          break;
      }
      this.sprite.y +=
        this.stats.speed * this.yDirection * 0.2 * time.deltaTime;
      if (this.sprite.label == "left") {
        this.sprite.x -= this.scatterSpeed * time.deltaTime;
      } else if (this.sprite.label == "right") {
        this.sprite.x += this.scatterSpeed * time.deltaTime;
      }
    }
  }

  private scatter(bullet: Bullet) {
    let x = bullet.sprite.x - bullet.sprite.width / 2;
    const y = bullet.sprite.y;

    const left = new Bullet(
      bullet.entity,
      bullet.type,
      bullet.yDirection,
      x,
      y,
    );
    left.sprite.label = "left";
    left.sprite.alpha = 0.5;
    this.entity.bullets.push(left);

    x = bullet.sprite.x + bullet.sprite.width / 2;
    const right = new Bullet(
      bullet.entity,
      bullet.type,
      bullet.yDirection,
      x,
      y,
    );
    // const right = this.spawn(bullet.sprite.x + bullet.sprite.width/2, bullet.sprite.y);
    right.sprite.label = "right";
    right.sprite.alpha = 0.5;
    bullet.scattered = true;
    this.entity.bullets.push(right);
    // this.entity.bullets.forEach( (b) => {console.log(b.sprite.label)})
  }

  // TODO probably belongs in Game
  private getStats(type: number) {
    return {
      1: {
        texture: "bullet1",
        behavior: "normal",
        speed: 10 - 1,
        sound: "enemyShoot1",
      },
      2: {
        texture: "bullet2",
        behavior: "grow",
        speed: 6,
        sound: "shoot1",
      },
      3: {
        texture: "bullet3",
        behavior: "scatter",
        speed: 10 - 0.75,
        sound: "enemyShoot",
      },
    }[type];
  }
}
