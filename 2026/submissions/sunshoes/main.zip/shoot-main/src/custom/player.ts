import { FederatedPointerEvent, Sprite, Ticker } from "pixi.js";
import { Entity } from "./entity";
import { Game } from "./game";
import { Bullet } from "./bullet";
import { sound } from "@pixi/sound";

export class Player extends Entity {
  constructor(health: number, game: Game) {
    super(1, health, game);
    // console.log(`creating player w/ health ${this.health}`)
    this.texture = "player";
  }

  public spawn() {
    const entity = Sprite.from(this.texture);
    entity.anchor.set(0.5);
    entity.scale.set(0.05);
    entity.position.set(
      this.game.app.screen.width / 2,
      this.game.app.screen.height - entity.height,
    );
    entity.label = "player";

    this.game.app.stage.addChild(entity);
    this.sprite = entity;
    this.game.app.stage.on("pointermove", this.move.bind(this));
    return entity;
  }

  /**
   * shoot
   */
  public shoot() {
    if (!this.sprite || this.shootOnCooldown) return;
    const x = this.sprite.x;
    const y = this.sprite.y;
    const bullet = new Bullet(this, this.bulletType, -1, x, y);
    if (this.sprite) this.bullets.push(bullet);
    this.cooldown();
  }

  private cooldown() {
    this.shootOnCooldown = true;
    setTimeout(() => {
      this.shootOnCooldown = false;
    }, this.shootCooldown);
  }
  /**
   * move
   */
  public move(event: FederatedPointerEvent) {
    if (!this.sprite.destroyed) {
      const width = this.sprite.width / 2;
      const height = this.sprite.height / 2;
      const pos = event.global;
      if (pos.x <= this.game.app.screen.width - width && pos.x >= width) {
        this.sprite.x = pos.x;
      }
      if (pos.y <= this.game.app.screen.height - height && pos.y >= height) {
        this.sprite.y = pos.y;
      }
    }
  }

  /**
   * takeDamage - reduces health by 1
   * if health reaches 0 call destroy
   */
  public takeDamage() {
    this.health--;
    this.game.playerDamageTaken++;
    this.game.removeLife(this);
    if (this.health <= 0) {
      this.game.music.stop();
      this.destroy();
      const rand = Math.floor(Math.random() * 2) + 1;
      setTimeout(() => {
        sound.play(`player_death_${rand}`, {
          complete: () => {
            this.game.end(false);
          },
        });
      }, 400);
    } else {
      sound.play(`player_hit_0${this.game.playerDamageTaken}`);
    }
  }

  /**
   * update
   */
  public update(time: Ticker) {
    super.update(time);
    this.game.enemies.forEach((enemy) => {
      enemy.bullets.forEach((bullet) => {
        if (this.collided(bullet.sprite)) {
          bullet.sprite.destroy();
          this.takeDamage();
        }
      });
    });
  }
}
