import { Bullet } from "./bullet";
import { Entity } from "./entity";
import { Game } from "./game";
import { Sprite, Ticker } from "pixi.js";

interface NumberKeyObject {
  [key: number]: EnemyStat;
}

interface EnemyStat {
  texture: string;
  health: number;
  fireRate: number;
}

export class Enemy extends Entity {
  public direction: number = 1;
  public stats: EnemyStat;

  constructor(type: number, game: Game) {
    super(type, 0, game);
    this.stats = this.getStats(type);
    this.health = this.stats.health;
    this.texture = this.stats.texture;
    this.fireRate = this.stats.fireRate;
    this.sprite = this.spawn();
    this.shootCooldown = this.stats.fireRate;
  }

  /**
   * spawn
   */
  public spawn() {
    const enemy = Sprite.from(this.texture);
    enemy.anchor = 0.5;
    enemy.scale.set(0.075);
    enemy.x = Math.floor(Math.random() * this.game.app.stage.width);
    enemy.y = -enemy.height;
    enemy.rotation = Math.PI;
    this.game.app.stage.addChild(enemy);
    return enemy;
  }

  /**
   * update
   */
  public update(time: Ticker) {
    if (!this.sprite.destroyed) {
      this.move();
      this.shoot();
    } else if (this.sprite.destroyed && this.bullets.length === 0) {
      this.game.enemies = [];
    }
    this.bullets.forEach((bullet) => {
      bullet.update(time);
    });

    // collides w/ player bullets
    this.game.player.bullets.forEach((bullet) => {
      if (this.collided(bullet.sprite)) {
        bullet.sprite.destroy();
        this.takeDamage();
      }
    });
  }

  public shoot() {
    if (
      !this.sprite ||
      this.shootOnCooldown ||
      this.game.player.sprite.destroyed
    )
      return;
    const x = this.sprite.x;
    const y = this.sprite.y;
    const bullet = new Bullet(this, this.bulletType, 1, x, y);
    if (this.sprite) this.bullets.push(bullet);
    this.cooldown();
  }

  private move() {
    if (this.sprite.y < 25) {
      this.sprite.y += 1;
    } else {
      const currentDirection = this.direction;
      let newDirection = currentDirection;
      const random = Math.floor(Math.random() * 500);
      if (random === 1) {
        newDirection = -newDirection;
      } else {
        // on right side, moving right
        if (
          this.sprite.x >= this.game.app.screen.width - this.sprite.width / 2 &&
          currentDirection == 1
        ) {
          newDirection = -1;
          // on right side, moving left
        } else if (
          this.sprite.x >= this.game.app.screen.width &&
          currentDirection == -1
        ) {
          newDirection = -1;
          // on left side, moving right
        } else if (
          this.sprite.x <= this.game.app.screen.width &&
          currentDirection == 1
        ) {
          newDirection = 1;
          // on left side, moving left
        } else if (this.sprite.x <= 15 && currentDirection == -1) {
          newDirection = 1;
        }
        this.sprite.x += newDirection;
      }
      this.direction = newDirection;
    }
    // return newDirection;
  }

  private cooldown() {
    // add randomness
    this.shootOnCooldown = true;
    setTimeout(() => {
      this.shootOnCooldown = false;
    }, this.shootCooldown);
  }

  private getStats(type: number) {
    const stats: NumberKeyObject = {
      1: {
        texture: "enemy1",
        health: 1,
        fireRate: 750,
      },
      2: {
        texture: "enemy2",
        health: 4,
        fireRate: 800,
      },
      3: {
        texture: "enemy3",
        health: 6,
        fireRate: 750,
      },
    };
    return stats[type];
  }
}
