import { AnimatedSprite, Assets, Sprite, Ticker } from "pixi.js";
import { Bullet } from "./bullet";
import { Game } from "./game";
import { sound } from "@pixi/sound";

export class Entity {
  public health: number;
  public texture: string;
  public fireRate: number;
  public bulletType: number;
  public sprite: Sprite;
  public game: Game;
  public shootCooldown: number = 250;
  public shootOnCooldown: boolean = false;
  public bullets: Array<Bullet> = [];

  constructor(bulletType: number, health: number, game: Game) {
    this.health = health;
    this.texture = "";
    this.fireRate = 0;
    this.bulletType = bulletType;
    this.sprite = Sprite.from("");
    this.game = game;
  }

  /**
   * takeDamage - reduces health by 1
   * if health reaches 0 call destroy
   */
  public takeDamage() {
    this.health--;
    if (this.health <= 0) {
      this.destroy();
      this.game.removeLife(this);
    } else {
      sound.play("hit");
    }
  }

  /**
   * collided
   */
  public collided(otherSprite: Sprite) {
    if (this.sprite.destroyed || otherSprite.destroyed) {
      return false;
    }
    // get the bounding rectangles of both this.sprite
    const bounds1 = this.sprite.getBounds();
    const bounds2 = otherSprite.getBounds();

    // check if rectangles overlap
    // TODO make box smaller since sprites have a lot of transparency
    return (
      bounds1.x < bounds2.x + bounds2.width &&
      bounds1.x + bounds1.width > bounds2.x &&
      bounds1.y < bounds2.y + bounds2.height &&
      bounds1.y + bounds1.height > bounds2.y
    );
  }

  /**
   * shoot - fires bullet a direction
   * returns Bullet object
   */
  public shoot() {
    if (!this.sprite) return;
    const x = this.sprite.x;
    const y = this.sprite.y;
    new Bullet(this, this.bulletType, 1, x, y);
    // need to know entity x,y position
    // b.spawn(this.)
  }

  /**
   * update
   */
  public update(time: Ticker) {
    // move bullets
    // move entity
    this.bullets.forEach((bullet) => {
      bullet.update(time);
    });
  }

  /**
   * destroy - play death animation
   */
  public destroy() {
    const animation = Assets.cache.get("explosion").animations;
    const explosion = new AnimatedSprite(animation["explosion"]);
    const bounds = this.sprite.getBounds();
    explosion.animationSpeed = 0.16;
    explosion.loop = false;
    explosion.position.set(bounds.x, bounds.y);
    explosion.play();
    sound.play("explosion2");

    this.game.app.stage.addChild(explosion);
    this.sprite.destroy();

    setTimeout(() => {
      explosion.destroy();
    }, 500);
  }
}
