/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const main_js: (a: number) => void;
export const receive_op_js: (a: number, b: number) => void;
export const set_difficulty_js: (a: number) => void;
export const get_result_display_delay_ms: () => number;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_1: WebAssembly.Table;
export const __wbindgen_exn_store: (a: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_export_6: WebAssembly.Table;
export const closure4_externref_shim: (a: number, b: number, c: any) => void;
export const closure7_externref_shim: (a: number, b: number, c: any, d: any) => void;
export const closure496_externref_shim: (a: number, b: number, c: any) => void;
export const _dyn_core_e5750d0c2d62f9b0___ops__function__FnMut_____Output______as_wasm_bindgen_f6733f9fb734dd19___closure__WasmClosure___describe__invoke______: (a: number, b: number) => void;
export const closure560_externref_shim: (a: number, b: number, c: any) => void;
export const __wbindgen_start: () => void;
