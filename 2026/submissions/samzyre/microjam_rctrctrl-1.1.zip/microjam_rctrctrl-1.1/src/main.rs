use notan::draw::*;
use notan::math::{Mat4, Rect};
use notan::prelude::*;

const WIDTH: f32 = 240.0;
const HEIGHT: f32 = 160.0;
#[cfg(target_arch = "wasm32")]
const SCALE: f32 = 1.0; // scaling doesn't work right with harness
#[cfg(not(target_arch = "wasm32"))]
const SCALE: f32 = 3.0;
const DT: f32 = 1.0 / 60.0;

#[cfg(target_arch = "wasm32")]
mod harness {
    use std::cell::RefCell;
    use wasm_bindgen::prelude::*;

    thread_local! {
        pub static START_REQUEST: RefCell<Option<f32>> = RefCell::new(None);
    }

    #[wasm_bindgen]
    extern "C" {
        pub fn send_ready();
        pub fn send_started(verb: String);
        pub fn send_done(win: bool);
    }

    #[wasm_bindgen]
    pub fn game_start(difficulty: f32) {
        START_REQUEST.with(|s| {
            *s.borrow_mut() = Some(difficulty);
        });
    }
}

#[cfg(not(target_arch = "wasm32"))]
mod harness {
    use std::cell::RefCell;

    thread_local! {
        pub static START_REQUEST: RefCell<Option<f32>> = RefCell::new(Some(1.0));
    }

    pub fn send_ready() {}
    pub fn send_started(_verb: String) {}
    pub fn send_done(win: bool) {
        START_REQUEST.set(Some(win as u32 as f32 * 50.0));
    }
}

pub fn take_start_request() -> Option<f32> {
    harness::START_REQUEST.with(|s| s.borrow_mut().take())
}

#[derive(AppState, Default)]
struct State {
    font: Option<Font>,
    mouse: Mouse,
    mouse_pos: (f32, f32),
    delta_acc: f32,
    delta: f32,
    uptime: f32,
    rng: Random,
    visual: Visual,
    system: System,
    rtfm: Rtfm,
    speed: f32,
    started: bool,
}

impl State {
    fn reset(&mut self, difficulty: f32) {
        *self = Self {
            mouse: Mouse::Up,
            mouse_pos: (0.0, 0.0),
            delta_acc: 0.0,
            delta: 0.0,
            uptime: 0.0,
            rng: Random::default(),
            visual: Visual::default(),
            system: System {
                data: Random::default().random(),
                ..Default::default()
            },
            rtfm: Rtfm {
                scribble: Random::default().random(),
                ..Default::default()
            },
            started: false,
            speed: 1.0,
            ..*self
        };
        self.visual.aggression += f32::log2(difficulty + 1.0) * 0.3;
    }
}

#[notan_main]
fn main() -> Result<(), String> {
    notan::init_with(setup)
        .add_config(DrawConfig)
        .add_config(WindowConfig {
            title: "rctrctrl".to_string(),
            width: (WIDTH * SCALE) as u32,
            height: (HEIGHT * SCALE) as u32,
            min_size: Some((WIDTH as u32, HEIGHT as u32)),
            max_size: Some(((WIDTH * SCALE) as u32, (HEIGHT * SCALE) as u32)),
            vsync: true,
            resizable: true,
            // lazy_loop: true,
            ..Default::default()
        })
        .event(event)
        .update(update)
        .draw(draw)
        .build()
}

fn setup(gfx: &mut Graphics) -> State {
    let font = gfx.create_font(include_bytes!("assets/Ubuntu-B.ttf")).ok();
    gfx.set_size(WIDTH as u32, HEIGHT as u32);
    harness::send_ready();
    State {
        font,
        mouse: Mouse::Up,
        ..Default::default()
    }
}

fn event(state: &mut State, evt: Event) {
    if !state.started {
        return;
    }
    match evt {
        Event::MouseDown { .. } => {
            state.mouse = Mouse::Down;
        }
        Event::MouseUp { .. } => {
            state.mouse = Mouse::Up;
        }
        _ => {}
    }
}

fn update(app: &mut App, _a: &mut Assets, _p: &mut Plugins, state: &mut State) {
    if !state.started {
        if let Some(difficulty) = take_start_request() {
            state.reset(difficulty);
            state.started = true;
            harness::send_started("stabilize!".into());
        } else {
            return;
        }
    }
    state.delta = app.timer.delta_f32();
    state.delta_acc += state.delta;
    while state.delta_acc >= DT {
        tick(state);
        state.delta_acc -= DT;
    }
    let p = app.mouse.position();
    state.mouse_pos = (p.0 / SCALE, p.1 / SCALE);
    state.rtfm.update(state.mouse_pos, state.mouse.is_pressed());
    state
        .system
        .update(state.mouse_pos, state.mouse.is_pressed());
    if state
        .visual
        .core
        .contains(state.mouse_pos.0, state.mouse_pos.1)
    {
        state.visual.angle = state.uptime * 500.0;
        state.speed = 5.0;
    } else {
        state.speed = 1.0;
    }
}

fn tick(state: &mut State) {
    state.uptime += DT;
    state.visual.random = state.rng.random();
    state.visual.aggression += f32::sqrt(state.uptime) * 0.0025 * state.speed;
    state.visual.aggression -= (0.11 + state.system.control).powf(state.speed)
        * f32::sqrt(state.uptime)
        * 0.0025
        * state.speed;
    state.visual.aggression = state.visual.aggression.clamp(0.0, 9.0);
    state.system.tick();
    // End conditions
    if state.visual.cooked() > 0.99 {
        state.reset(0.0);
        harness::send_done(false);
    } else if state.visual.cooked() < 0.01 && state.uptime > 1.0 {
        state.reset(0.0);
        harness::send_done(true);
    }
}

fn draw(gfx: &mut Graphics, state: &mut State) {
    if !state.started {
        return;
    }

    let mut d = gfx.create_draw();
    d.clear(Color::from_hex(0x887755FF));
    d.set_projection(Some(Mat4::orthographic_rh_gl(
        0.0, WIDTH, HEIGHT, 0.0, -1.0, 1.0,
    )));

    // everything below is 240x160 coordinates
    render_visual(&mut d, state);
    render_controls(&mut d, state);
    render_rtfm(&mut d, state);

    d.circle(1.0)
        .position(state.mouse_pos.0, state.mouse_pos.1)
        .color(Color::WHITE);

    gfx.render(&d);
}

fn render_visual(d: &mut Draw, state: &mut State) {
    let a = &mut state.visual.angle;
    let r = state.visual.random * state.visual.aggression * 0.1;
    let v = decimate(r);
    *a += v * decimate(state.visual.aggression);

    d.circle(45.0 * v)
        .position(70.0, 65.0)
        .stroke(11.0)
        .tolerance(v)
        .stroke_color(Color::from_hex(0xAAAA88FF));
    d.circle(35.0 * v)
        .position(70.0, 65.0)
        .stroke(11.0)
        .tolerance(v)
        .stroke_color(Color::from_hex(0xFF888888));
    d.circle(25.0 * v)
        .position(70.0, 65.0)
        .stroke(11.0)
        .tolerance(v)
        .stroke_color(Color::from_hex(0xCC888888));

    for ang in [0.0, 120.0, 240.0] {
        d.triangle((70.0, 65.0), (18.0, 55.0), (55.0, 15.0))
            .skew(-r * 0.1, -r * 0.1)
            .rotate_degrees_from((70.0, 65.0), *a + ang)
            .color_vertex(
                Color::from_hex(0x00AACCCC),
                Color::from_hex(0xAA884400),
                Color::from_hex(0xAAAA88FF),
            );
    }

    d.circle(50.0 * decimate(v))
        .position(70.0, 65.0)
        .stroke(11.0)
        .stroke_color(Color::from_hex(0xCCAA88FF));
    d.circle(25.0 * v)
        .position(70.0, 65.0)
        .tolerance(v)
        .color(Color::from_hex(0x0088FF88));

    d.polygon(6, 50.0)
        .position(70.0, 65.0)
        .stroke(2.0)
        .color(Color::from_hex(0xCCBBAA88));
    d.polygon(8, 66.0)
        .position(70.0, 65.0)
        .stroke(2.0)
        .color(Color::from_hex(0x665544FF));

    d.line((8.0, 131.0), (130.0, 131.0))
        .color(Color::from_hex(0x665544FF));
    d.line((141.0, 5.0), (141.0, 130.0))
        .color(Color::from_hex(0x665544FF));
    d.line((150.0, 60.0), (230.0, 60.0))
        .color(Color::from_hex(0x665544FF));

    d.text(
        &state.font.unwrap(),
        &format!("{:.3} T", state.visual.aggression),
    )
    .position(114.0, 1.0)
    .size(8.0)
    .color(Color::from_hex(0x443322FF));
    d.text(
        &state.font.unwrap(),
        &format!("C {:.1}", state.system.control),
    )
    .position(114.0, 10.0)
    .size(8.0)
    .color(Color::from_hex(0x443322FF));
    d.rect((134.0, 9.0), (4.0, 112.0))
        .color(Color::from_hex(0x665544FF));
    d.rect((135.0, 10.0), (2.0, 110.0)).color_vertex(
        Color::from_hex(0xFF0000FF),
        Color::from_hex(0x88FF00FF),
        Color::from_hex(0x00FF88FF),
        Color::from_hex(0xFF0088FF),
    );
    d.rect((134.0, 10.0), (4.0, 110.0 - state.visual.cooked() * 110.0))
        .color(Color::from_hex(0x665544CC));

    if state
        .visual
        .core
        .contains(state.mouse_pos.0, state.mouse_pos.1)
    {
        d.text(&state.font.unwrap(), ">>>")
            .position(10.0, 5.0)
            .size(10.0)
            .color(Color::from_hex(0x443322FF));
    }
}

fn render_rtfm(d: &mut Draw, state: &mut State) {
    d.text(&state.font.unwrap(), "RTFM")
        .position(160.0, 30.0)
        .size(20.0)
        .rotate_degrees_from((160.0, 30.0), 90.0)
        .h_align_center()
        .v_align_middle()
        .color(Color::from_hex(0x554433FF));

    let r = state.rtfm.button.rect;
    d.rect((r.x - 5.0, r.y - 5.0), (r.width + 10.0, r.height + 10.0))
        .color(Color::from_hex(0x775533FF));

    d.rect((r.x, r.y), (r.width, r.height))
        .color(state.rtfm.button.color())
        .stroke(state.uptime % 1.0 + 2.0)
        .fill();

    for (y, &w) in state.rtfm.scribble.iter().enumerate() {
        if w > 0.2 {
            h_line(
                d,
                (r.x + 2.0, r.y + 5.0 + (y * 2) as f32),
                r.width - 20.0 * w - 5.0,
            )
            .color(Color::BLACK.with_alpha(0.5));
        }
    }

    d.rect((r.x + r.width * 0.5 - 6.0, r.y - 7.0), (12.0, 7.0))
        .color(Color::from_hex(0x778899FF));

    // Readme
    if state.rtfm.button.pressed {
        render_notes(d, state);
    }
}

fn render_notes(d: &mut Draw, state: &mut State) {
    d.rect((40.0, 10.0), (WIDTH - 80.0, HEIGHT - 20.0))
        .color(Color::from_hex(0xFFEEAAEE));
    d.text(&state.font.unwrap(), "Read you!")
        .position(80.0, 10.0)
        .color(Color::BLACK);

    let data = &state.system.data;
    for (i, m) in data[0..3].iter().enumerate() {
        d.text(&state.font.unwrap(), &format!("RC_{}", i + 1))
            .position(50.0 + 50.0 * i as f32, 30.0)
            .size(10.0)
            .color(Color::BLACK);
        d.rect((55.0 + 50.0 * i as f32, 45.0), (10.0, 20.0))
            .color(Color::from_hex(0x88888888));
        d.rect((55.0 + 50.0 * i as f32, 45.0 + 15.0 * m), (10.0, 5.0))
            .color(Color::from_hex(0x112233FF));
    }

    d.text(&state.font.unwrap(), "VECTOR INTERCEPT CONTROL FIELD")
        .position(50.0, 75.0)
        .size(8.0)
        .color(Color::BLACK);
    d.rect((60.0, 85.0), (60.0, 30.0))
        .stroke(2.0)
        .color(Color::from_hex(0x88888888));
    d.rect((60.0 + 50.0 * data[3], 85.0 + 20.0 * data[4]), (10.0, 10.0))
        .color(Color::from_hex(0x112233FF));

    d.text(&state.font.unwrap(), "STATE COMBULATOR")
        .position(50.0, 120.0)
        .size(8.0)
        .color(Color::BLACK);
    for (i, &m) in data[5..13].iter().enumerate() {
        let color = if on(m) {
            Color::from_hex(0x112233FF)
        } else {
            Color::from_hex(0x88888888)
        };
        d.rect((50.0 + 15.0 * i as f32, 130.0), (10.0, 10.0))
            .color(color);
    }
}

fn render_controls(d: &mut Draw, state: &mut State) {
    for s in state.system.sliders.iter() {
        let p = s.position();
        d.rect((s.rect.x + 5.0, s.rect.y), (8.0, s.rect.height + s.limit.1))
            .color(Color::from_hex(0x33221188));
        d.line(
            (s.rect.x + 6.0, s.rect.y + s.limit.1 * 0.5),
            (p.0 + 5.0, p.1 + 5.0),
        )
        .color(Color::from_hex(0x332211FF));
        d.circle(2.5)
            .position(s.rect.x + 6.0, s.rect.y + s.limit.1 * 0.5)
            .color(Color::from_hex(0x332211FF));
        d.line(
            (s.rect.x + 12.0, s.rect.y + s.limit.1 * 0.5),
            (p.0 + 14.0, p.1 + 5.0),
        )
        .color(Color::from_hex(0x332211FF));
        d.circle(2.5)
            .position(s.rect.x + 12.0, s.rect.y + s.limit.1 * 0.5)
            .color(Color::from_hex(0x332211FF));
        d.rect(p, (s.rect.width, s.rect.height)).color(s.color());
    }

    let z = &state.system.zone;
    d.rect(
        (z.rect.x - 3.0, z.rect.y - 3.0),
        (
            z.rect.width + z.limit.0 + 6.0,
            z.rect.height + z.limit.1 + 6.0,
        ),
    )
    .color(Color::from_hex(0x33221188));
    let p = z.position();
    d.circle(5.0).position(p.0, p.1).color(z.color());

    for t in state.system.toggles.iter() {
        d.circle(t.rect.width * 0.5)
            .position(t.rect.center_x(), t.rect.center_y())
            .color(t.color());
        // d.rect((b.rect.x, b.rect.y), (b.rect.width, b.rect.height))
        //     .color(b.color());
    }
}

struct Visual {
    angle: f32,
    aggression: f32,
    random: f32,
    core: Rect,
}

impl Default for Visual {
    fn default() -> Self {
        Self {
            angle: Default::default(),
            aggression: 2.0,
            random: Default::default(),
            core: Rect {
                x: 55.0,
                y: 50.0,
                width: 30.0,
                height: 30.0,
            },
        }
    }
}

impl Visual {
    fn cooked(&self) -> f32 {
        (self.aggression / 5.0).clamp(0.0, 1.0)
    }
}

struct System {
    data: [f32; 13],
    sliders: Vec<Slider>,
    zone: Slider,
    toggles: Vec<Toggle>,
    control: f32,
}

impl System {
    fn update(&mut self, pos: (f32, f32), pressed: bool) {
        for s in self.sliders.iter_mut() {
            s.update(pos, pressed);
        }
        self.zone.update(pos, pressed);
        for t in self.toggles.iter_mut() {
            t.update(pos, pressed);
        }
    }

    fn tick(&mut self) {
        let mut error = 0.0;
        for (i, s) in self.sliders.iter().enumerate() {
            error += (self.data[i] - s.value.1).abs() * 2.0;
        }
        error += (self.data[3] - self.zone.value.0).abs() * 1.5;
        error += (self.data[4] - self.zone.value.1).abs() * 1.5;
        for (i, t) in self.toggles.iter().enumerate() {
            if on(self.data[i + 5]) != t.pressed {
                error += 1.0;
            }
        }
        let max = 17.0;
        self.control = (1.0 - error / max).clamp(0.0, 1.0);
    }
}

impl Default for System {
    fn default() -> Self {
        let mut sliders = Vec::new();
        for i in 0..3 {
            sliders.push(Slider {
                value: (0.0, 0.5),
                rect: Rect {
                    x: 155.0 + 25.0 * i as f32,
                    y: 70.0,
                    width: 20.0,
                    height: 5.0,
                },
                limit: (0.0000001, 25.0),
                hover: false,
                colors: (Color::from_hex(0xBB2222FF), Color::from_hex(0xCC3333FF)),
            });
        }
        let mut toggles = Vec::new();
        for i in 0..8 {
            toggles.push(Toggle {
                rect: Rect {
                    x: 15.0 + 15.0 * i as f32,
                    y: 137.0,
                    width: 12.0,
                    height: 12.0,
                },
                hover: false,
                pressed: false,
                switched: false,
                colors: (Color::from_hex(0x662222FF), Color::from_hex(0x44FF44FF)),
            });
        }
        Self {
            data: Default::default(),
            sliders,
            zone: Slider {
                value: (0.5, 0.5),
                rect: Rect {
                    x: 160.0,
                    y: 115.0,
                    width: 1.0,
                    height: 1.0,
                },
                limit: (60.0, 30.0),
                hover: false,
                colors: (Color::from_hex(0xBB2222FF), Color::from_hex(0xCC3333FF)),
            },
            toggles,
            control: 0.0,
        }
    }
}

struct Rtfm {
    button: Button,
    scribble: [f32; 15],
}

impl Rtfm {
    fn update(&mut self, pos: (f32, f32), pressed: bool) {
        self.button.update(pos, pressed);
    }
}

impl Default for Rtfm {
    fn default() -> Self {
        Self {
            button: Button {
                rect: Rect {
                    x: 185.0,
                    y: 10.0,
                    width: 30.0,
                    height: 40.0,
                },
                hover: false,
                pressed: false,
                colors: (
                    Color::from_hex(0xFFFF88FF),
                    Color::from_hex(0xFFFFCCFF),
                    Color::from_hex(0xFFEEAAEE),
                ),
            },
            scribble: Default::default(),
        }
    }
}

struct Button {
    rect: Rect,
    hover: bool,
    pressed: bool,
    colors: (Color, Color, Color),
}

impl Button {
    fn contains(&self, pos: (f32, f32)) -> bool {
        self.rect.contains(pos.0, pos.1)
    }

    fn color(&self) -> Color {
        if self.pressed {
            self.colors.2
        } else if self.hover {
            self.colors.1
        } else {
            self.colors.0
        }
    }

    fn update(&mut self, pos: (f32, f32), pressed: bool) {
        self.hover = self.contains(pos);
        if self.hover {
            self.pressed = pressed;
        } else {
            self.pressed = false;
        }
    }
}

struct Toggle {
    rect: Rect,
    hover: bool,
    pressed: bool,
    switched: bool,
    colors: (Color, Color),
}

impl Toggle {
    fn contains(&self, pos: (f32, f32)) -> bool {
        self.rect.contains(pos.0, pos.1)
    }

    fn color(&self) -> Color {
        if self.pressed {
            self.colors.1
        } else {
            self.colors.0
        }
    }

    fn update(&mut self, pos: (f32, f32), pressed: bool) {
        self.hover = self.contains(pos);
        if self.hover && pressed && !self.switched {
            self.pressed = !self.pressed;
            self.switched = true;
        } else if !pressed {
            self.switched = false;
        }
    }
}

struct Slider {
    value: (f32, f32),
    rect: Rect,
    limit: (f32, f32),
    hover: bool,
    colors: (Color, Color),
}

impl Slider {
    fn contains(&self, pos: (f32, f32)) -> bool {
        let r = Rect {
            x: self.rect.x,
            y: self.rect.y,
            width: self.rect.width + self.limit.0,
            height: self.rect.height + self.limit.1,
        };
        r.contains(pos.0, pos.1)
    }

    fn update(&mut self, pos: (f32, f32), pressed: bool) {
        self.hover = self.contains(pos);
        if self.hover && pressed {
            let x = (pos.0 - self.rect.height * 0.5 - self.rect.x) / self.limit.0;
            let y = (pos.1 - self.rect.height * 0.5 - self.rect.y) / self.limit.1;
            self.value = (x.clamp(0.0, 1.0), y.clamp(0.0, 1.0));
        }
    }

    fn position(&self) -> (f32, f32) {
        let px = self.rect.x + self.value.0 * self.limit.0;
        let py = self.rect.y + self.value.1 * self.limit.1;
        (px, py)
    }

    fn color(&self) -> Color {
        if self.hover {
            self.colors.1
        } else {
            self.colors.0
        }
    }
}

#[derive(Copy, Clone, Default, PartialEq)]
enum Mouse {
    #[default]
    Up,
    Down,
}

impl Mouse {
    fn is_pressed(&self) -> bool {
        *self == Self::Down
    }
}

fn decimate(value: f32) -> f32 {
    value * 0.1 + 0.9
}

fn h_line(d: &mut Draw, start: (f32, f32), length: f32) -> DrawBuilder<'_, Line> {
    d.line((start.0, start.1), (start.0 + length, start.1))
}

fn on(d: f32) -> bool {
    d > 0.5
}
