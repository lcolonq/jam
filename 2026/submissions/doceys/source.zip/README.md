# My Entry for the [LCOLONQ Microjam 2026](https://api.colonq.computer/jam/2026)

## Building and running

Build the Jai code to WASM:
```bash
jai build.jai
```

Run the game outside of the Jam Harness:
```bash
python3 -m http.server -d ./public
```
