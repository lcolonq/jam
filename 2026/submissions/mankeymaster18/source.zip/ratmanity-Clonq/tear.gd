extends RigidBody2D

@export var initial_velocity: Vector2

func _ready() -> void:
	linear_velocity = initial_velocity
	rotation = initial_velocity.angle()

func _physics_process(delta: float) -> void:
	if linear_velocity.length_squared() > 0.01:
		rotation = linear_velocity.angle()	
