extends Area2D

var collected = 0;
var yd = Vector2(0.0,0.0);
var xp = Vector2(0.0,0.0);
var xd = Vector2(0.0,0.0);
var k1= 0.0;
var k2= 0.0;
var k3= 0.0;
var f = 8.0;
var r = 0.5;
var z = 1.0;
# bounds of the window.
var bounds = Rect2(Vector2(0,125), Vector2(640, 480))
signal tear_collected

func _collect_tear(body: Node2D) -> void:
	if(collected < 5):
		collected += 1
	tear_collected.emit(1)
	var pitch = randf_range(0.9,1.2)
	if !$waterCollected.is_playing():
		$waterCollected.pitch_scale = pitch
		$waterCollected.play()
	body.queue_free()

#Collect tear if coliding with a tear
func _ready() -> void:	
	body_entered.connect(_collect_tear)
	#Set mouse to center
	Input.warp_mouse(Vector2(640,480)/2)
	#z is zdamping, f is frequency, and r is the response
	k1 = z / (PI * f)
	k2 = 1/ ((2 * PI * f) * (2 * PI * f))
	k3 = r * z / (2 * PI * f)
	
	

func _process(delta: float) -> void:
	# Found this math in the video giving personality to procedural animation
	# using math by t3ssel8r!
	var x = get_global_mouse_position()
	if(x != xp):
		xd = (x - xp)/delta
		# Seems to consistently go to this value at the start of the game.
		# setting the derivative of x to 0 at start.
		if(xd.x == 19199.998046875 && xd.y == 14399.9990234375):
			xd = Vector2(0.0,0.0)
	
	if(x != position && bounds.has_point(x)):
		# Keep this within bounds so that if there were sudden lag spikes the 
		# value does not become to large
		var k2_stable = max(k2, 1.1*f * (delta * delta/4 + delta*k1/2))
		position += (delta * yd)
		#Show directional movement with rotation
		rotation = clamp(-0.001*yd.x,-0.5,0.5)
		#Semi-implicit euler method for determining the yd over time
		yd = yd + delta * (x + (k3*xd) - position - k1*yd) / k2_stable
		
	xp = x
 
