extends Node2D

#Started and ended values for controling game flow
var started = false
var ended = false
var time: float = 10.0
var timeElapsed: float = 0.0
var goal = 0
var difficulty = 0

static func is_colonq_build():
	return OS.has_feature("colonq")

func _update_tear_value(collected: int) -> void:
	var bar = get_node("collectedTears")
	bar.value += collected

func _clear_children() -> void:
	var children = find_children("tear*", "", true, false);
	for x in children:
		x.queue_free();

func update_timer(timeElapsed: float) -> void:
	var bar = get_node("collectedTears")
	var timer = get_node("timer")
	var seconds = int(time - timeElapsed) % 60
	if seconds > 0:
		timer.text = "%02d" % seconds
	elif bar.value >= goal:
		ended = true
		_clear_children()
		timer.text = "VICTORY"
	else:
		ended = true
		_clear_children()
		timer.text = "LOSS"
		

func start_game(difficulty) -> void:
	started = true
	timeElapsed = 0.0
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	goal = int(clamp(0.2 * difficulty, 10, 15))
	var bar = get_node("collectedTears")
	bar.max_value = goal
	JavaScriptBridge.eval("window.parent.postMessage({op: \"started\"});")

func game_end() -> void:
	var bar = get_node("collectedTears")
	var timer = get_node("timer")
	if(bar.value >= goal):
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")
		get_tree().reload_current_scene()
	else:
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")
		get_tree().reload_current_scene()

func _ready() -> void:
	get_node("handBox").tear_collected.connect(_update_tear_value)
	JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});")

func _process(delta: float) -> void:
	if (is_colonq_build()):
		difficulty = JavaScriptBridge.eval("window.lcolonqJamStart || -1.0")
	else:
		difficulty = randi_range(0, 100)
	if !started &&  difficulty > 0.0:
		start_game(difficulty)
	elif started:
		timeElapsed += delta
		update_timer(timeElapsed)
		if(timeElapsed >= time):
			game_end()
	else:
		pass
