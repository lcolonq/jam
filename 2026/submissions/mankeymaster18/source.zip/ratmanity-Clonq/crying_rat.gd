extends AnimatedSprite2D

var tear_count = 0
var max_tears = 2
const tear_scene = preload("res://tear.tscn")


func _on_projectile_exited():
	tear_count-=1
	
func _ready() -> void:
	play()
	pass 

func spawn_tear():
	var tear = tear_scene.instantiate()
	var x = randf_range(-1.0, 1.0)
	tear.initial_velocity = Vector2(x, -1.0)*300
	tear.global_position = global_position + Vector2(50,35)
	get_parent().add_child(tear)	
	tear_count += 1
	var pitch = randf_range(0.9,1.2)
	if !$mouseSqueak.is_playing():
		$mouseSqueak.pitch_scale = pitch
		$mouseSqueak.play()
	tear.tree_exited.connect(_on_projectile_exited)

func _process(delta: float) -> void:
	#Limit spawn rate (very badly) I am not very sharp...
	if(int(get_parent().timeElapsed)%2 == 0):
		#If game has started and game has not ended keep spawning.
		if(tear_count < max_tears && !get_parent().ended && get_parent().started):
			spawn_tear()
			
