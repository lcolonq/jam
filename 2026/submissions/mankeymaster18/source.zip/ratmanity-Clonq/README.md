First game I have ever made. Thank you mr. colonq for helping me get into something new.
If you run into any issues you can message me on discord @mankey. :D
I will be making some more updates to this ahead of the 28th.
