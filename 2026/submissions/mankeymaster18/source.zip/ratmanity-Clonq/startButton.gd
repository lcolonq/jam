extends Button


func _on_pressed():
	get_tree().change_scene_to_file("res://game.tscn")

func _ready() -> void:
	pressed.connect(_on_pressed)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
