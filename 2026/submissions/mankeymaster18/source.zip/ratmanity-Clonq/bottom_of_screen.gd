extends Area2D

#Delete tear if it reaches the bottom of the screen uncollected
func _remove_tear(body: Node2D) -> void:
	body.queue_free()
	
func _ready() -> void:
	body_entered.connect(_remove_tear)
	
func _process(delta: float) -> void:
	pass
