extends Node2D

@onready var markers = [$FirstMarker, $SecondMarker, $ThirdMarker]
@onready var animation_player: AnimationPlayer = $AnimationPlayer

const POSITION_OFFSET = 12

var marker_count
var buttons = []

var game_started = false
var game_lost = false

func _ready() -> void:
	for button in $Buttons/ColorRect.get_children():
		(button as Button).pressed.connect(on_button_pressed.bind(button))
	$AnimationPlayer.animation_finished.connect(func(anim_name):
		if anim_name == "game": lose_game())
	reset_game()
	JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});")

func _process(_delta: float) -> void:
	if OS.has_feature('web'):
		if !game_started && JavaScriptBridge.eval("window.lcolonqJamStart || -1.0") > 0.0:
			var minigames = JavaScriptBridge.eval("window.lcolonqJamStart || -1.0")
			var difficulty = clampi(ceili(minigames / 10), 1, 3)
			start_game(difficulty)
	#if !game_started:
		#if Input.is_action_just_pressed("debug_level1"): start_game(1)
		#elif Input.is_action_just_pressed("debug_level2"): start_game(2)
		#elif Input.is_action_just_pressed("debug_level3"): start_game(3)

func reset_game():
	$AnimationPlayer.play("RESET")
	var initial_markers = $SpawnMarkers.get_children()
	initial_markers.shuffle()
	for button:Button in $Buttons/ColorRect.get_children():
		var button_offset = Vector2(randi_range(-POSITION_OFFSET, POSITION_OFFSET), randi_range(-POSITION_OFFSET, POSITION_OFFSET))
		button.disabled = false
		button.global_position = initial_markers[button.get_index()].global_position + button_offset

func start_game(difficulty:int):
	game_started = true
	game_lost = false
	JavaScriptBridge.eval("window.parent.postMessage({op: \"started\", verb: \"cure!\"});")
	%WrongButton1.visible = difficulty != 1
	%WrongButton2.visible = difficulty != 1
	%WrongButton3.visible = difficulty != 1
	%CRTFilter.material.set("shader_parameter/vhs_intensity", 0.0 if difficulty != 3 else 3.0)
	%CRTFilter.material.set("shader_parameter/opacity", 0.2 if difficulty != 3 else 0.5)
	marker_count = 0
	buttons = []
	animation_player.play("game")
	$BGM.play()

func on_button_pressed(button:Button):
	if marker_count < 3:
		$ButtonSound.play()
		buttons.append(button)
		button.disabled = true
		var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		tween.tween_property(button, "global_position", markers[marker_count].global_position, 0.15)
		marker_count += 1
		if marker_count < 3:
			markers[marker_count].global_position.x = markers[marker_count-1].global_position.x + button.size.x + 8
		tween.tween_callback(check_status)

func check_status():
	if marker_count < 3: return
	if game_lost: return
	if buttons[0] == %FirstButton and buttons[1] == %SecondButton and buttons[2] == %ThirdButton:
		win_game()
	else: lose_game()

func win_game():
	$BGM.stop()
	$AnimationPlayer.play("win")
	await $AnimationPlayer.animation_finished
	reset_game()
	game_started = false
	JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")

func lose_game():
	$BGM.stop()
	game_lost = true
	$AnimationPlayer.play("fail")
	await $AnimationPlayer.animation_finished
	reset_game()
	game_started = false
	JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")
