# TODO for later

[ ] MAYBE we might need to make the grab area of the I piece a bit wider

[ ] pieces merging ideas:
	piece merging can make things harder or easier for the player
	- EASIER: any full rectangular areas composed of any number of pieces that dont 
	  overflow outside the rectangle can merge into one? ...doesnt seme to happen often
	- HARDER: all 1-block pieces are merged into any adjacent piece
	- EASIER: fully surrounded empty cells (single) merges all its neighbors into one
	  and fills the missing cell
	- EASIER: when a piece is "well placed" it merges with nearby "well placed" pieces
	  deciding whether a piece is well placed has to do with whether it made the overall shape more
	  convex than before.

merge_with_neighbor()
# find a neighbor whose face touches this piece
	# loop through all the neighboring blocks, find its piece, check its head position
# if not found, can't merge!
# perhaps avoid 1-block pieces
# then, once found, we delete both pieces and create a new one with both blocks!


TETROMINO: determine de amount of points needed?
basically, after initializing the shape, we need an intermediate value that is
lines to blocks..


[ ] Better Controls: HOLD + TOGGLE
	we want to support both toggle and hold modes, and we'll use a small timer to
	detect which one to "use".
	after first click on a piece, we wait for 0.3 seconds, if we dont receive a 
	release signal within that time frame, we're going to assume the user intends
	to use "hold" mode, otherwise, it's "toggle" mode.
	toggle mode means: click to grab, click to drop
	hold mode meaans: press to grab, release to drop
