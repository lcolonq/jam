extends Piece
class_name PiecePreview
@onready var timer_body: Node2D = %PreviewBody
@onready var pv_cells_1: PreviewCells = %pv_cells_1
@onready var pv_cells_2: PreviewCells = %pv_cells_2

var prev_shape : Piece.SHAPE_KIND
var showing_first_pv_cells : bool = true
var tween_flip : Tween 

func _init() -> void:
	shape_base_kind = SHAPE_KIND.O
	is_destructable = false


func _ready() -> void:
	super()
	showing_first_pv_cells = true
	_prepare_next_change(pv_cells_1, pv_cells_2)
	

func _process(_delta : float) -> void:
	super(_delta)
	#position
	var block_offset   : Vector2i = shape.blocks[0]
	var block_cell_pos : Vector2i = cell.grid_pos + block_offset
	var block_cell     : Cell     = Grid.get_cell_at(block_cell_pos)
	timer_body.global_position = block_cell.global_position + _next_cell_offset
	
	
	if not Game.next_shapes.is_empty():
		var next_shape = Game.next_shapes.back()
		if prev_shape != next_shape:
			#prints("shape changed")
			_on_next_shape_changed(next_shape)


func _on_next_shape_changed(next_shape : Piece.SHAPE_KIND) -> void:
	var from : PreviewCells = pv_cells_1 if showing_first_pv_cells else pv_cells_2
	var to   : PreviewCells = pv_cells_2 if showing_first_pv_cells else pv_cells_1
	
	_prepare_next_change(from, to)
	
	const duration := 0.8
	
	if tween_flip: tween_flip.kill()
	tween_flip = get_tree().create_tween()
	tween_flip.set_parallel(true)
	tween_flip.set_trans(Tween.TRANS_CIRC)
	tween_flip.set_ease(Tween.EASE_IN)
	#hide current
	tween_flip.tween_property(
		from, "offset_transform_scale", Vector2(1.0, 0.0), duration
	)
	tween_flip.tween_property(
		from, "offset_transform_position_ratio", Vector2(0, .5), duration
	)
	tween_flip.tween_property(
		from, "modulate", Color.BLACK, duration
	)
	#reveal next
	tween_flip.tween_property(
		to, "offset_transform_scale", Vector2.ONE, duration
	)
	tween_flip.tween_property(
		to, "offset_transform_position_ratio", Vector2.ZERO, duration
	)
	tween_flip.tween_property(
		to, "modulate", Color.WHITE, duration
	)
	
	tween_flip.tween_callback(func() -> void:
		Game.particles_place.spawn_at(
			cell.global_position + cell.get_combined_pivot_offset()
		)
		Sounds.play(Sounds.CLICK, randf_range(0.7, 1.0), linear_to_db(0.3))
	).set_delay(duration)

	from.offset_transform_scale = Vector2(1.0, 1.0)
	to.offset_transform_scale = Vector2(1.0, 0.0)
	to.shape = next_shape
	# -----
	showing_first_pv_cells = not showing_first_pv_cells
	prev_shape = next_shape
	
	for i : int in 5:
		await Sounds.play(Sounds.CLICK, randf_range(1.5, 2.0), linear_to_db(0.15)).finished



func _prepare_next_change(from : PreviewCells, to : PreviewCells) -> void:
	from.modulate = Color.WHITE
	from.offset_transform_scale = Vector2.ONE
	from.offset_transform_position_ratio = Vector2.ZERO
	to.modulate = Color(1.5, 1.5, 1.5)
	to.offset_transform_scale = Vector2.ZERO
	to.offset_transform_position_ratio = Vector2(0, -0.5)
