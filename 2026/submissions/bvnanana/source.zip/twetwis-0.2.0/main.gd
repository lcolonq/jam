extends Control
class_name Game

var _clonkjam_started : bool = false

enum GAME_STATE {IN_PROGRESS, WIN, LOSE}
var game_state : GAME_STATE = GAME_STATE.IN_PROGRESS

const TEXT_SCENE : PackedScene = preload("res://combo_text.tscn")
const PIECE_SCENE : PackedScene = preload("res://piece.tscn")
const TIMER_PIECE_SCENE : PackedScene = preload("res://piece_timer.tscn")
const BUTTON_PIECE_SCENE : PackedScene = preload("res://piece_button.tscn")
const PREVIEW_PIECE_SCENE : PackedScene = preload("res://piece_preview.tscn")
const ROTATE_TIME : float = 0.15

#caches and stuff
static var _pieces : Array[Piece] = []
static var next_shapes : Array[Piece.SHAPE_KIND] = []
static var _occupied_cells : Array[Vector2i] = []
static var _cell_to_block : Dictionary[Vector2i, PieceBlockHandle] = {}

class PieceBlockHandle:
	var piece : Piece
	var block_index : int
	func _init(_piece : Piece, _block_index : int) -> void:
		self.piece = _piece
		self.block_index = _block_index
		assert(_block_index < _piece.shape.blocks.size())
		assert(_block_index >= 0)


#grabbing pieces
static var piece_grabbed : Piece = null
static var piece_grab_offset : Vector2
enum GRAB_MODE {TOGGLE, HOLD}
#var _grab_mode = GRAB_MODE.HOLD
static var is_mouse_clicking : bool = false
static var gravity_paused : bool = false
var gravity_speed : float = 0.3
var total_rows_cleared : int = 0

@onready var bgm_player: AudioStreamPlayer = $BGM
@onready var spawn_timer: Timer = $SpawnTimer
@onready var game_timer: Timer = $GameTimer
@onready var fps_counter: Label = %FPSCounter
@onready var particles_clear: CanvasGroup = $ParticlesClear
static var particles_place: CanvasGroup

#camera 
static var camera : Camera2D
static var camera_shake_strength : float = 0.0
static var camera_shake_duration : float = 0.25

@onready var grayscale_shader: ColorRect = %grayscale_shader
@onready var post_proc: CanvasLayer = $post_proc


func _ready() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval(
			"window.parent.postMessage({op: \"ready\"});"
		)
	
	#reset static vars
	_pieces = []
	next_shapes = []
	_occupied_cells = []
	_cell_to_block = {}
	piece_grabbed = null
	piece_grab_offset = Vector2.ZERO
	is_mouse_clicking = false
	gravity_paused = false
	
	particles_place = $ParticlesPlace
	camera = $Camera2D
	
	fps_counter.queue_free()
	
	_preload_base_piece()
	
	#dont start automatically
	#_start_game.call_deferred()


func _start_game(difficulty : float) -> void:
	if _clonkjam_started: return
	_clonkjam_started = true
	bgm_player.pitch_scale = 0.8
	bgm_player.play()
	
	var timer_pos   := Vector2i(Grid.WIDTH - 1, 5)
	var button_pos  := Vector2i(1, 6)
	var preview_pos := Vector2i(Grid.WIDTH - 1, 1)

	@warning_ignore_start("integer_division")
	if difficulty > 50:
		game_timer.wait_time = 60.0
		spawn_timer.wait_time = 2.0
		gravity_speed = 0.25
		timer_pos   = Vector2i(Grid.WIDTH / 2, 5)
		button_pos  = Vector2i(Grid.WIDTH / 2, 8)
		preview_pos = Vector2i(Grid.WIDTH / 2, 1)
	elif difficulty > 40:
		game_timer.wait_time = 60.0
		spawn_timer.wait_time = 2.0
		gravity_speed = 0.25
		timer_pos   = Vector2i(1, 5)
		button_pos  = Vector2i(Grid.WIDTH - 1, 6)
		preview_pos = Vector2i(1, 1)
	elif difficulty > 30:
		game_timer.wait_time = 60.0
		spawn_timer.wait_time = 2.0
		gravity_speed = 0.3
	elif difficulty > 20:
		game_timer.wait_time = 55.0
		spawn_timer.wait_time = 2.0
		gravity_speed = 0.3
	elif difficulty > 10:
		game_timer.wait_time = 50.0
		spawn_timer.wait_time = 2.5
		gravity_speed = 0.3
	else:
		game_timer.wait_time = 45.0
		spawn_timer.wait_time = 2.5
		gravity_speed = 0.3
	@warning_ignore_restore("integer_division")
	#game timer
	game_timer.one_shot = true
	game_timer.start()
	
	#piece spawn timer
	spawn_timer.start()
	
	#instantiate timer piece
	var timer_piece : Piece = TIMER_PIECE_SCENE.instantiate()
	timer_piece.game_timer = game_timer
	timer_piece.init_from_base_shape_kind(
		Piece.SHAPE_KIND.O,
		Grid.get_cell_at(timer_pos)
	)
	_spawn_piece(timer_piece)
	
	#instantiate button piece
	var button_piece : Piece = BUTTON_PIECE_SCENE.instantiate()
	button_piece.init_from_base_shape_kind(
		Piece.SHAPE_KIND.O,
		Grid.get_cell_at(button_pos)
	)
	_spawn_piece(button_piece)
	connect_button.call_deferred(button_piece)

	#instantiate preview piece
	var preview_piece : Piece = PREVIEW_PIECE_SCENE.instantiate()
	preview_piece.init_from_base_shape_kind(
		Piece.SHAPE_KIND.O,
		Grid.get_cell_at(preview_pos)
	)
	_spawn_piece(preview_piece)
	
	#text
	await get_tree().create_timer(.5).timeout
	@warning_ignore("integer_division")
	spawn_text_at(
		"[wave freq=12 amp=22]%ds LEFT[i]!" % game_timer.wait_time,
		Grid.HEIGHT / 2 - 1, 2.5
	)
	


func connect_button(button_piece: PieceButton) -> void:
	button_piece.button.pressed.connect(rotate_falling)


func _game_timer_finished() -> void:
	game_state = GAME_STATE.WIN
	Game.gravity_paused = true
	game_timer.stop()
	spawn_timer.stop()
	await get_tree().create_timer(1.5).timeout
	@warning_ignore("integer_division")
	spawn_text_at(
		"[tornado freq=12 radius=2][wave freq=12 amp=22]WELL DONE[i]!",
		Grid.HEIGHT / 2 - 1,
		15.0,
		post_proc
	)
	
	var victory_song : AudioStreamPlayer = Sounds.play(Sounds.VICTORY, 1.2, 0.8)
	bgm_player.stop()

	for row in Grid.HEIGHT:
		await _clear_row(row)
		_clear_deleted_pieces()
		_build_caches()

	await victory_song.finished
	_clonkjam_end()
	


func spawn_text_at(
	text : String,
	row : int,
	duration : float = 2.0,
	parent : Node = self
) -> void:
	var label := TEXT_SCENE.instantiate()
	label.text = text
	label.global_position.y = Grid.get_cell_at(Vector2i(0, row)).global_position.y
	label.offset_transform_enabled = true
	label.offset_transform_scale = Vector2(0.8, 0.1)
	label.offset_transform_position = Vector2(0, 10)
	label.modulate.a = 0.0
	var text_tween : Tween = get_tree().create_tween()
	text_tween.set_ease(Tween.EASE_IN_OUT)
	text_tween.set_trans(Tween.TRANS_BACK)
	text_tween.parallel().tween_property(label, "modulate:a", 1.0, 0.15)
	text_tween.parallel().tween_property(label, "offset_transform_position", Vector2.ZERO, 0.3)
	text_tween.parallel().tween_property(label, "offset_transform_scale", Vector2.ONE, 0.3)
	text_tween.tween_interval(duration + 0.3)
	text_tween.tween_property(label, "offset_transform_position", Vector2(0, -10), 0.5)
	text_tween.parallel().tween_property(label, "modulate:a", 0.0, 0.3).set_trans(Tween.TRANS_BOUNCE)
	text_tween.tween_callback(label.queue_free)
	parent.add_child(label)


func game_over() -> void:
	game_state = GAME_STATE.LOSE
	Game.gravity_paused = true
	game_timer.stop()
	spawn_timer.stop()
	@warning_ignore("integer_division")
	spawn_text_at(
		"[tornado  radius=2.0 freq=8]OUCH[i]!",
		Grid.HEIGHT / 2 - 1,
		15.0,
		post_proc
	)
	var game_over_tween = get_tree().create_tween()
	game_over_tween.set_parallel(true)
	game_over_tween.tween_property(bgm_player, "pitch_scale", 0.3, 1.0)
	game_over_tween.tween_method(Engine.set_time_scale, 1.0, 0.2, 1.0)
	game_over_tween.tween_method(
		func(val):
			grayscale_shader.set_instance_shader_parameter("saturation", val),
			1.0, 0.0, 0.3
		)
	game_over_tween.tween_callback(_clonkjam_end).set_delay(3.0)


func _process(delta: float) -> void:

	spawn_timer.paused = Game.gravity_paused
	game_timer.paused = Game.gravity_paused
	#fps_counter.text = "%d" % Engine.get_frames_per_second()
	_clonkjam_try_start()
	bag_randomizer()
	
	if not Game.gravity_paused:
		_process_rows()
	
	#screen shake
	if camera_shake_strength > 0:
		camera_shake_strength = lerpf(camera_shake_strength, 0, 1.0 / camera_shake_duration * delta)
		camera.offset = Vector2(
			randf_range(-camera_shake_strength, camera_shake_strength),
			randf_range(-camera_shake_strength, camera_shake_strength)
		)


func _process_rows() -> void:
	Game.gravity_paused = true
	_try_moving_grabbed_piece()
	_clear_deleted_pieces()
	_build_caches()
	_show_possible_moves()
	total_rows_cleared = 0
	await _clear_full_rows()
	Game.gravity_paused = false


func bag_randomizer() -> void:
	if not next_shapes.is_empty(): return
	next_shapes.append_array(Piece.SHAPE_KIND.values())
	#next_shapes.append_array([Piece.SHAPE_KIND.O])
	next_shapes.shuffle()


func _spawn_random_piece() -> void:
	bgm_player.pitch_scale = clamp(bgm_player.pitch_scale + 0.01, 0.8, 2.5)
	var next_shape = next_shapes.pop_back()
	const piece_height = 2 #TODO: not ideal!
	@warning_ignore("integer_division")
	var grid_pos := Vector2i(Grid.WIDTH / 2, piece_height)
	_spawn_base_piece(next_shape, grid_pos)


func _preload_base_piece() -> void:
	var piece : Piece = PIECE_SCENE.instantiate()
	piece.cell = Grid.get_cell_at(Vector2i(5,5))
	piece.shape = Piece.Shape.new([Vector2i.ZERO])
	add_child(piece)
	await RenderingServer.frame_post_draw
	piece.queue_free()


func _spawn_base_piece(shape : Piece.SHAPE_KIND, grid_pos : Vector2i) -> void:
	var piece : Piece = PIECE_SCENE.instantiate()
	piece.init_from_base_shape_kind(shape, Grid.get_cell_at(grid_pos))
	piece.gravity_speed = gravity_speed
	
	if not piece.can_spawn():
		return game_over()
	return _spawn_piece(piece)


func _spawn_piece(piece : Piece) -> void:
	#piece.landed.connect(try_merge_landed_piece.bind(piece))
	add_child(piece)
	_pieces.append(piece)


func _clonkjam_try_start() -> void:
	if not OS.has_feature("web"): return
	if _clonkjam_started: return

	var should_start : float = JavaScriptBridge.eval("window.lcolonqJamStart || -1.0")
	if  should_start > 0.0:
		_start_game(should_start)
		JavaScriptBridge.eval(
			"window.parent.postMessage({op: \"started\", verb: \"play twetwis!\"});"
		)


func _clonkjam_end() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval(
			"window.parent.postMessage({op: \"done\", win: %s});" % [
				"true" if game_state == GAME_STATE.WIN else "false"
		])
	await get_tree().create_timer(0.25).timeout
	for piece : Piece in _pieces:
		if is_instance_valid(piece): piece.queue_free()
	_pieces.clear()
	Engine.time_scale = 1.0
	get_tree().reload_current_scene()


static func _build_caches() -> void:
	_occupied_cells.clear()
	_cell_to_block.clear()
	for piece : Piece in _pieces:
		#occupied cells
		var piece_positions := piece.get_all_positions()
		_occupied_cells.append_array(piece_positions)
		#cell to block
		for i : int in piece_positions.size():
			var piece_pos : Vector2i = piece_positions[i]
			# WARNING: this is fragile af, we're relying on the fact
			#          that the piece_positions is created in order of the blocks
			# TODO: find a more robust way to do this instead!
			var block_index : int = i
			_cell_to_block[piece_pos] = PieceBlockHandle.new(piece, block_index)


static func get_occupied_cells() -> Array[Vector2i]:
	return _occupied_cells.duplicate()


func _input(event: InputEvent) -> void:
	if OS.is_debug_build() and event is InputEventKey:
		match event.keycode:
			KEY_F1: _start_game(1.0)
			KEY_F2: _start_game(11.0)
			KEY_F3: _start_game(21.0)
			KEY_F4: _start_game(31.0)
			KEY_F5: _start_game(41.0)
			KEY_F6: _start_game(51.0)
		return

	if event is not InputEventMouseButton:
		return 

	match event.button_index:
		MOUSE_BUTTON_LEFT:
			if event.is_pressed() and Cursor.piece_hovered:
				return grab_piece(
					Cursor.piece_hovered,
					Cursor.grabber_area.global_position
				)
			if event.is_pressed():
				#prints("click")
				if not Game.is_mouse_clicking and _clonkjam_started:
					Sounds.play(Sounds.CLICK, randf_range(2.5, 3.0), linear_to_db(0.35))
					particles_place.spawn_for_pointer_at(event.position)
					Game.is_mouse_clicking = true
				return ungrab_piece()
			Game.is_mouse_clicking = false
			if event.is_released() and piece_grabbed:
				return ungrab_piece()


static func grab_piece(piece : Piece, global_pos_origin : Vector2) -> void:
	if Game.piece_grabbed:
		return

	Game.piece_grabbed = piece
	piece.is_grabbed = true
	piece_grab_offset = global_pos_origin - piece.cell.global_position
	Sounds.play(Sounds.PLACE.pick_random(), randf_range(1.0, 1.5), linear_to_db(0.5))
	_show_possible_moves()


static func ungrab_piece() -> void:
	if not Game.piece_grabbed:
		return
	Game.piece_grabbed.is_grabbed = false
	Game.piece_grabbed = null
	Sounds.play(Sounds.PLACE.pick_random(), randf_range(1.0, 1.5), linear_to_db(0.5))
	_show_possible_moves()


static func is_piece_in_cell_moving(pos : Vector2i) -> bool:
	if not Game._cell_to_block.has(pos):
		return true
	if Game._cell_to_block[pos].piece == null:
		return true
	if not is_instance_valid(Game._cell_to_block[pos].piece):
		return true
	return Game._cell_to_block[pos].piece._next_cell != null


static func is_piece_grabbed_in_cell(pos : Vector2i) -> bool:
	if not Game._cell_to_block.has(pos):
		return false
	if Game._cell_to_block[pos].piece == null:
		return false
	if not is_instance_valid(Game._cell_to_block[pos].piece):
		return false
	return Game._cell_to_block[pos].piece == Game.piece_grabbed


func _try_moving_grabbed_piece() -> void:
	if not Game.piece_grabbed: return
	var cursor_pos : Vector2 = get_global_mouse_position()
	var dist : Vector2 = cursor_pos - (piece_grabbed.cell.global_position + piece_grab_offset)
	var cell_pixel_size : Vector2 = Grid.CELL_SIZE / 1.5
	Game.piece_grabbed.move_direction.x = int(dist.x / cell_pixel_size.x)
	#if Game.piece_grabbed.move_direction.x != 0:
		#prints("move_direction", Game.piece_grabbed.move_direction)
	

func rotate_falling() -> void:
	if game_state != GAME_STATE.IN_PROGRESS: return
	Game.gravity_paused = true
	_clear_deleted_pieces()
	for piece : Piece in _pieces:
		if not piece: continue
		if not is_instance_valid(piece): continue
		if not piece.is_inside_tree(): continue
		if not piece.is_destructable: continue
		_build_caches()
		piece.rotate_clockwise()
	Sounds.play(Sounds.SWOOSH.pick_random(), randf_range(0.8, 1.2))
	await get_tree().create_timer(Game.ROTATE_TIME).timeout
	Game.gravity_paused = false


static func _show_possible_moves() -> void:
	var allowed_rows : Array[int] = []
	if Game.piece_grabbed:
		for pos : Vector2i in Game.piece_grabbed.get_all_positions():
			if not allowed_rows.has(pos.y):
				allowed_rows.append(pos.y)
		#prints("get_all_positions", Game.piece_grabbed.get_all_positions())
		#prints("allowed rows", allowed_rows)
	for cell : Cell in Grid.get_cells():
		cell.bg.visible = false
		if allowed_rows.has(cell.grid_pos.y):
			cell.bg.visible = true


func _clear_row_text(row : int, combo : int = 0) -> void:
	var word : String
	var effect : String = "[tornado freq=12 radius=2][wave freq=12 amp=22]"
	match combo:
		0: word = "%sCLEAR[i]!" % effect
		1: word = "%sDOUBLE[i]!" % effect
		2: word = "%sTWIPLE[i]!" % effect
		3: word = "%sTWETWIS[i]!" % effect
		_: word = "[rainbow sat=.8 val=1.2 speed=2]%sWAOW[i]!" % effect
		
	await get_tree().create_timer(0.05 * Grid.WIDTH / 3).timeout
	@warning_ignore("narrowing_conversion")
	spawn_text_at(word, row, .15, post_proc)


func _clear_full_rows() -> void:
	#prints("clear ful rows...")
	for row in Grid.HEIGHT:
		if _is_row_full(row):
			_clear_row_text(row, total_rows_cleared)
			total_rows_cleared += 1
			#prints("row full!")
			if Game.piece_grabbed and Game.piece_grabbed.cell.grid_pos.y == row:
				ungrab_piece()
			await _clear_row(row)
			_clear_deleted_pieces()
			_build_caches()
			await _clear_full_rows()
			return


func _clear_deleted_pieces() -> void:
	var new_pieces : Array = _pieces.filter(
	func(piece) -> bool:
		return piece != null and is_instance_valid(piece)
	)
	_pieces.assign(new_pieces)


static func _is_row_full(row : int) -> bool:
	# we dont take into account the currently grabbed piece!
	if Game.piece_grabbed and Game.piece_grabbed.cell.grid_pos.y == row:
		return false
	for col in Grid.WIDTH:
		if not _occupied_cells.has(Vector2i(col, row)):
			return false
		if is_piece_in_cell_moving(Vector2i(col, row)):
			return false
	return true


func _clear_row(row : int) -> void:
	#prints("clearing row:", row)
	var blocks_to_delete : Dictionary[Piece, Array] = {}
	for col in Grid.WIDTH:
		var cell_key := Vector2i(col, row)
		#prints("cell_key:", clell_key)
		if not _cell_to_block.has(cell_key):
			continue
		var block_handle := _cell_to_block[cell_key]
		if not is_instance_valid(block_handle.piece):
			continue
		if not blocks_to_delete.has(block_handle.piece):
			blocks_to_delete[block_handle.piece] = []
		if not blocks_to_delete[block_handle.piece].has(block_handle.block_index):
			blocks_to_delete[block_handle.piece].append(block_handle.block_index)

	var pop_sfx_pitch : float = 1.0
	Game.screen_shake(1, .6)
	for piece : Piece in blocks_to_delete.keys():
		await get_tree().create_timer(0.05).timeout
		if not piece: continue
		if not is_instance_valid(piece): continue
		if not piece.is_inside_tree(): continue
		if not piece.is_destructable: continue
		var blocks : Array[int] = []
		blocks.assign(blocks_to_delete[piece])
		_remove_blocks(piece, blocks)
		Sounds.play(Sounds.POP, pop_sfx_pitch)
		pop_sfx_pitch += 0.15


func _remove_blocks(piece : Piece, block_indexes : Array[int]) -> void:
	#NOTE: removing a block CAN split the piece into multiple pieces.
	#      for example: removing a  block in the middle of the I piece results in
	#      two pieces. Also, if we had for example a piece in the shape of a + symbol,
	#      removing the middle block creates 4 separate pieces!

	# because of all this, instead of actually trying to remove the block
	# from the piece, we do the following:
	# - we assume every single block will become its own piece
	# - then we check adjacency to build the new array groups
	# - then for each array group we build entirely new pieces
	if piece == null: return
	if not is_instance_valid(piece): return
	if not piece.is_inside_tree(): return
	if not piece.is_destructable: return

	#TODO: better type safety somehow? Godot does not support Array[Array[Vector2i]] atm...
	var block_groups : Array[Array] = []
	for i : int in piece.shape.blocks.size():
		if block_indexes.has(i):
			# spawn explosion particle
			var cell := Grid.get_cell_at(piece.cell.grid_pos + piece.shape.blocks[i])
			particles_clear.spawn_at(cell.global_position + cell.get_combined_pivot_offset())
		else:
			block_groups.append([piece.shape.blocks[i]])
	
	#regroup!
	var regrouped : Array[Array] = []
	for group : Array in block_groups:
		var create_new_group : bool = true
		for regrouped_idx : int in regrouped.size():
			if _are_blocks_next_to_blocks(
				Array(group, TYPE_VECTOR2I, "", null),
				Array(regrouped[regrouped_idx], TYPE_VECTOR2I, "", null),
			):
				regrouped[regrouped_idx].append_array(group)
				create_new_group = false
		if create_new_group:
			regrouped.append(group)

	#create new pieces
	for block_group : Array in regrouped:
		var new_piece : Piece = PIECE_SCENE.instantiate()
		var new_origin_cell : Cell = Grid.get_cell_at(piece.cell.grid_pos + block_group[0])
		var origin_cell_offset : Vector2i = new_origin_cell.grid_pos - piece.cell.grid_pos
		var typed_block_group : Array[Vector2i] = []
		for block : Vector2i in block_group:
			typed_block_group.append(block - origin_cell_offset)
		new_piece.shape = Piece.Shape.new(typed_block_group)
		new_piece.cell  = new_origin_cell
		_spawn_piece(new_piece)
	
	#destroy original piece
	piece.queue_free()
	#prints("original:", piece.shape.blocks.size(), "will spawn:", regrouped.size())


func _are_blocks_next_to_blocks(a : Array[Vector2i], b : Array[Vector2i]) -> bool:
	# if the distance between two blocks is 1, they're next to each other
	# (since diagonals distance is > 1)
	for pos_1 : Vector2i in a:
		for pos_2 : Vector2i in b:
			if is_equal_approx(1.0, pos_1.distance_to(pos_2)):
				return true
	return false


static func screen_shake(pixels : int = 1, duration : float = .25) -> void:
	camera_shake_strength = pixels
	camera_shake_duration = duration


static func screen_zoom() -> void:
	#TODO: zoom?
	pass


func try_merge_landed_piece(landed_piece : Piece) -> void:
	if landed_piece.is_grabbed: return
	if landed_piece._next_cell: return
	if not landed_piece.is_destructable: return

	#find neighbor candidate
	for neighbor_pos : Vector2i in landed_piece.get_neighboring_positions():
		#TODO: actually check the face and validity, for now we just grab the first one
		if not Game._cell_to_block.has(neighbor_pos):
			continue
		var block_handle : Game.PieceBlockHandle = Game._cell_to_block[neighbor_pos]
		if not block_handle.piece or not is_instance_valid(block_handle.piece):
			continue
		var piece : Piece = block_handle.piece
		if piece == landed_piece: continue
		if not piece.is_destructable: continue
		return merge_pieces(landed_piece, piece)


func merge_pieces(first_piece: Piece, second_piece: Piece) -> void:
	first_piece.queue_free()
	second_piece.queue_free()

	var new_piece : Piece = PIECE_SCENE.instantiate()
	var origin_cell_offset : Vector2i = second_piece.cell.grid_pos - first_piece.cell.grid_pos
	var blocks : Array[Vector2i] = first_piece.shape.blocks.duplicate()
	for block : Vector2i in second_piece.shape.blocks:
		blocks.append(origin_cell_offset + block)
	
	#TODO: sort doesnt work becuase of the potential shapes
	#      probalby need to have multiple lines
	#      and maybe only merge them when the shape is convex somehow
	blocks.sort_custom(func(a: Vector2i, b:Vector2i) -> bool:
		return Vector2(a).angle() > Vector2(b).angle()
	)

	new_piece.shape = Piece.Shape.new(blocks)
	new_piece.shape.closed_loop = false
	new_piece.cell  = first_piece.cell	
	_spawn_piece(new_piece)
