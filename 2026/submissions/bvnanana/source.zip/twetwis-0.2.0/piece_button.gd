extends Piece
class_name PieceButton
@onready var timer_body: Node2D = %ButtonBody
@onready var button: Button = $ButtonBody/TextureRect/Button

func _init() -> void:
	shape_base_kind = SHAPE_KIND.O
	is_destructable = false


func _process(delta : float) -> void:
	super(delta)
	#position
	var block_offset   : Vector2i = shape.blocks[0]
	var block_cell_pos : Vector2i = cell.grid_pos + block_offset
	var block_cell     : Cell     = Grid.get_cell_at(block_cell_pos)
	timer_body.global_position = block_cell.global_position + _next_cell_offset
	
	#pressed
	if button.button_pressed:
		button.offset_transform_position = button.offset_transform_position.lerp(
			Vector2(0, 2), delta * 24.0
		)
	else:
		button.offset_transform_position = button.offset_transform_position.lerp(
			Vector2.ZERO, delta * 8.0
		)
