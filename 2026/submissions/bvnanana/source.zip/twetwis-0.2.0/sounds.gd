extends Node

 #NOTE: this apparently improves performance a bit
@onready var scene_tree : SceneTree = get_tree()

const VOICE : Array[AudioStream] = [
	preload("res://sfx/voices/a.wav"),
	preload("res://sfx/voices/e.wav"),
	preload("res://sfx/voices/i.wav"),
	preload("res://sfx/voices/o.wav"),
	preload("res://sfx/voices/u.wav"),
]
const VICTORY : AudioStream = preload("res://song_victory.mp3")
const TIMER_TICK : AudioStream = preload("res://sfx/metal-small1.wav")
const MOVE : AudioStream = preload("res://sfx/interface2_pitched.wav")
const POP : AudioStream = preload("res://sfx/pop.ogg")
const LAND_INDESTRUCTIBLE : AudioStream = preload("res://sfx/interface6.wav")
const LAND : AudioStream = preload("res://sfx/cloth.wav")
const PLACE : Array[AudioStream] = [
	preload("res://sfx/slime1.wav"),
	preload("res://sfx/slime3.wav"),
	preload("res://sfx/slime4.wav"),
	preload("res://sfx/slime5.wav"),
]
const CLICK : AudioStream = preload("res://sfx/interface1.wav")
const SWOOSH : Array[AudioStream] = [
	preload("res://sfx/swing.wav"),
	preload("res://sfx/swing2.wav"),
	preload("res://sfx/swing3.wav")
]

func play(
	sound: AudioStream,
	pitch_scale : float = 1.0,
	volume_db : float = 0.0
) -> AudioStreamPlayer:
	var player := AudioStreamPlayer.new()
	player.stream = sound
	player.autoplay = true
	player.pitch_scale = pitch_scale
	player.volume_db = volume_db
	player.finished.connect(func(): player.queue_free())
	scene_tree.current_scene.add_child(player)
	return player
