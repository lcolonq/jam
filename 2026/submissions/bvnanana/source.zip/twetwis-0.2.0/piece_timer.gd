extends Piece
class_name PieceTimer
@onready var timer_body: Node2D = %TimerBody
@onready var progress_bar: TextureProgressBar = %progress_bar
@onready var texture_rect: TextureRect = $TimerBody/TextureRect
@onready var time_up_text: RichTextLabel = %time_up_text

const TEXT_SCENE : PackedScene = preload("res://timer_text.tscn")

@export var game_timer : Timer
var blink_tween : Tween
var ring_tween : Tween

var last_shown_text : int = 9999

func _init() -> void:
	shape_base_kind = SHAPE_KIND.O
	is_destructable = false

func _ready() -> void:
	super()
	assert(game_timer)


func _exit_tree() -> void:
	if blink_tween: blink_tween.kill()
	if ring_tween: ring_tween.kill()


func _process(_delta : float) -> void:
	super(_delta)
	
	if Game.gravity_paused: return

	#game timer
	progress_bar.min_value = 0.0
	progress_bar.max_value = game_timer.wait_time
	progress_bar.value = game_timer.time_left
	
	if progress_bar.value < 10 and not blink_tween:
		z_index = 10
		blink_tween = get_tree().create_tween()
		blink_tween.set_loops()
		blink_tween.tween_property(progress_bar, "tint_progress", Color.WHITE, .5)
		blink_tween.tween_property(progress_bar, "tint_progress", Color.CRIMSON, .5)
		blink_tween.parallel().tween_property(texture_rect, "scale", Vector2(1.1, 1.1), 0.1)
		blink_tween.tween_property(texture_rect, "scale", Vector2.ONE, 0.1)
		
	if (progress_bar.value < 10
	and progress_bar.value > 0
	and last_shown_text > progress_bar.value):
		#prints("PIECE TIMER: %d" % last_shown_text)
		last_shown_text = progress_bar.value as int
		show_number("%d" % last_shown_text)
	
	if progress_bar.value == 0 and not ring_tween:
		time_up_text.visible = true
		blink_tween.stop()
		ring_tween = get_tree().create_tween()
		ring_tween.set_loops()
		ring_tween.parallel().tween_property(time_up_text, "scale", Vector2(1.1, 1.1), 0.1)
		ring_tween.tween_property(time_up_text, "scale", Vector2.ONE, 0.1)
		ring_tween.parallel().tween_property(texture_rect, "scale", Vector2(1.1, 1.1), 0.1)
		ring_tween.tween_property(texture_rect, "scale", Vector2.ONE, 0.1)
		ring_tween.parallel().tween_property(texture_rect, "rotation", deg_to_rad(5), 0.1)
		ring_tween.tween_callback(func(): Sounds.play(Sounds.POP, 1.8))
		ring_tween.tween_property(texture_rect, "rotation", deg_to_rad(-5), 0.1)
		ring_tween.tween_callback(func(): Sounds.play(Sounds.POP, 1.5))
		
		Game.screen_shake(1, 3.0)

	#position
	var block_offset   : Vector2i = shape.blocks[0]
	var block_cell_pos : Vector2i = cell.grid_pos + block_offset
	var block_cell     : Cell     = Grid.get_cell_at(block_cell_pos)
	timer_body.global_position = block_cell.global_position + _next_cell_offset
	
		
func show_number(text : String, duration : float = 0.5) -> void:
	var label := TEXT_SCENE.instantiate()
	label.text = text
	label.global_position = timer_body.global_position
	label.offset_transform_enabled = true
	label.offset_transform_scale = Vector2(1.0, 0.1)
	label.offset_transform_position = Vector2(0, 10)
	label.modulate.a = 0.0
	var text_tween : Tween = get_tree().create_tween()
	text_tween.set_ease(Tween.EASE_IN_OUT)
	text_tween.set_trans(Tween.TRANS_BACK)
	text_tween.parallel().tween_property(label, "modulate:a", 1.0, 0.15)
	text_tween.parallel().tween_property(label, "offset_transform_position", Vector2.ZERO, 0.3)
	text_tween.parallel().tween_property(label, "offset_transform_scale", Vector2.ONE, 0.3)
	text_tween.tween_interval(duration)
	text_tween.tween_property(label, "offset_transform_position", Vector2(0, -10), 0.5)
	text_tween.parallel().tween_property(label, "modulate:a", 0.0, 0.3).set_trans(Tween.TRANS_BOUNCE)
	text_tween.tween_callback(label.queue_free)
	add_child(label)
	Sounds.play(Sounds.TIMER_TICK, 1.5)
