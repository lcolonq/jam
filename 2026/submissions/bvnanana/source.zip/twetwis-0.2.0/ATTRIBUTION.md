# 3rd PARTY ASSETS

1. RPG Sound Pack
	- LICENSE: CC0
	- SOURCE: https://opengameart.org/content/rpg-sound-pack
	- AUTHOR: farfadet46

2. Bubbles 'Pop'
	- LICENSE: CC0
	- SOURCE: https://opengameart.org/content/bubbles-pop
	- AUTHOR: artisticdude

3. Vowel Sounds from Animalese Generator
	- LICENSE: MIT
	- SOURCE: https://github.com/equalo-official/animalese-generator
	- AUTHOR: equalo-official

4. Chonkly Font
	- LICENSE: CC0
	- SOURCE: https://arcadiaxdev.itch.io/chonkly-pixel-font
	- AUTHOR: Aaron O'Rourke
