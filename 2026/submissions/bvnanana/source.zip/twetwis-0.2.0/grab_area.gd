extends Area2D
class_name PieceGrabArea
@onready var piece: Piece = $".."
