extends CanvasGroup

var particles_clear_scene := preload("res://particles_clear.tscn")


func _ready() -> void:
	for child in get_children():
		child.queue_free()


func spawn_at(global_pos : Vector2) -> void:
	var particles : GPUParticles2D = particles_clear_scene.instantiate()
	particles.global_position = global_pos
	particles.emitting = true
	particles.one_shot = true
	particles.lifetime = randf_range(0.4, 0.6)
	#particles.explosiveness = randf_range(0.5, 0.8)
	particles.finished.connect(particles.queue_free)
	#var particle_delay : float = randf_range(0.0, 0.15)
	#await get_tree().create_timer(particle_delay).timeout
	add_child(particles)
