extends GridContainer
class_name Grid

@onready var cell_template: Cell = %Cell

const HEIGHT : int = 14
const WIDTH  : int = 16
const CEILING_ROW : int = 1
static var CELL_SIZE : Vector2

static var _cell_map : Dictionary[Vector2i, Cell] = {}

func _ready() -> void:
	columns = WIDTH
	CELL_SIZE = cell_template.get_rect().size

	for y in HEIGHT:
		for x in WIDTH:
			var new_cell : Cell = cell_template.duplicate()
			new_cell.grid_pos = Vector2i(x, y)
			new_cell.name = "cell_%d_%d" % [x, y]
			_cell_map[new_cell.grid_pos] = new_cell
			if y <= CEILING_ROW:
				new_cell.modulate.a = 0.0
			add_child(new_cell)
	
	cell_template.queue_free()


static func get_cell_at(pos : Vector2i) -> Cell:
	assert(_cell_map.has(pos))
	return _cell_map[pos]


static func cell_exists(pos : Vector2i) -> bool:
	return _cell_map.has(pos)


static func get_cells() -> Array[Cell]:
	return _cell_map.values()
