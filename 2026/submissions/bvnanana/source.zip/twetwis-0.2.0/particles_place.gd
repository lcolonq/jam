extends CanvasGroup

var particles_place_scene := preload("res://particles_place.tscn")
var particles_pointer_scene := preload("res://particles_pointer.tscn")


func _ready() -> void:
	for child in get_children():
		child.queue_free()


func spawn_at(global_pos : Vector2) -> void:
	var particles : GPUParticles2D = particles_place_scene.instantiate()
	particles.global_position = global_pos
	particles.emitting = true
	particles.one_shot = true
	particles.lifetime = randf_range(.6, 1.)
	particles.finished.connect(particles.queue_free)

	add_child(particles)


func spawn_for_pointer_at(global_pos : Vector2) -> void:
	var particles : GPUParticles2D = particles_pointer_scene.instantiate()
	particles.global_position = global_pos
	particles.emitting = true
	particles.one_shot = true
	particles.lifetime = randf_range(.5, .6)
	particles.finished.connect(particles.queue_free)

	add_child(particles)
