extends Control
class_name Cell

var grid_pos : Vector2i
@onready var bg: Panel = $cell_bg
