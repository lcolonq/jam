extends Control

var text : String = ""
@onready var combo_text: RichTextLabel = $combo_text

func _ready() -> void:
	combo_text.text = text
