extends Node2D
class_name Cursor

static var grabber_area: Area2D
static var palm: Node2D
static var index_finger: Node2D
static var middle_finger: Node2D
static var ring_finger: Node2D
static var pinky_finger: Node2D
static var other_fingers: Node2D
static var all_fingers_grab: Node2D

static var piece_hovered : Piece = null
static var pieces_under_cursor : Array[PieceGrabArea] = []

@onready var canvas_group: CanvasGroup = %CanvasGroup
@onready var sprites: Node2D = $CanvasGroup/sprites

static var animation_tween : Tween

enum CURSOR_STATE {
	POINTER,
	CLICK,
	HOVER,
	GRAB
}

static var state : CURSOR_STATE : set = set_state

static func set_state(new_state : CURSOR_STATE) -> void:
	state = new_state
	match state:
		CURSOR_STATE.POINTER, CURSOR_STATE.CLICK:
			palm.visible             = true
			index_finger.visible     = true
			other_fingers.visible    = false
			all_fingers_grab.visible = false
		CURSOR_STATE.HOVER:
			palm.visible             = true
			index_finger.visible     = true
			other_fingers.visible    = true
			all_fingers_grab.visible = false
		CURSOR_STATE.GRAB:
			palm.visible             = true
			index_finger.visible     = false
			other_fingers.visible    = false
			all_fingers_grab.visible = true
	

func _ready() -> void:
	palm = %palm
	index_finger = %index_finger
	other_fingers = %other_fingers
	middle_finger = %middle_finger
	ring_finger = %ring_finger
	pinky_finger = %pinky_finger
	all_fingers_grab = %all_fingers_grab
	grabber_area = %grabber_area
	
	#reset static vars
	piece_hovered = null
	pieces_under_cursor = []
	if animation_tween: animation_tween.kill()
	animation_tween = null
	
	set_state(CURSOR_STATE.POINTER)
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN


func _process(delta: float) -> void:
	#TODO: it would be nice to find a way to confine this to the horizontal
	#      movement of the piece when Game.piece_grabbed exists, but right 
	#      it wont work because once it finishes, it bounces out to the global mouse pos
	#      so it needs to be done with an entirely virtual mouse pos or smth like that
	global_position = get_global_mouse_position()
	
	_select_hovered_piece_under_cursor()
	
	#state
	state = CURSOR_STATE.HOVER if piece_hovered else CURSOR_STATE.POINTER
	if Game.is_mouse_clicking:
		state = CURSOR_STATE.CLICK
	if Game.piece_grabbed:
		state = CURSOR_STATE.GRAB

	if state == CURSOR_STATE.GRAB:
		canvas_group.self_modulate.a = 0.0
	else:
		canvas_group.self_modulate.a = 4.0
	
	if state == CURSOR_STATE.HOVER:
		sprites.scale = sprites.scale.lerp(Vector2(0.6, 0.6), delta * 10.0)
	else:
		sprites.scale = sprites.scale.lerp(Vector2(0.5, 0.5), delta * 10.0)

	if state == CURSOR_STATE.CLICK:
		index_finger.scale.y = 0.8
	else:
		index_finger.scale.y = 1.0

	#rotation
	var cursor_rotation : float = deg_to_rad(15)
	var screen_size : Vector2 = get_viewport_rect().size
	if get_global_mouse_position().x > screen_size.x / 2:
		cursor_rotation = deg_to_rad(-15)
	sprites.rotation = lerp_angle(
		sprites.rotation,
		cursor_rotation,
		delta * 10.0
	)
	
	if other_fingers.visible and not animation_tween:
		#prints("create tween")
		animation_tween = get_tree().create_tween()
		animation_tween.set_loops()
		animation_tween.tween_interval(0.3)
		animation_tween.tween_property(pinky_finger, "scale:y", 0.75, 0.15)
		animation_tween.tween_property(pinky_finger, "scale:y", 1.0, 0.1)
		animation_tween.parallel().tween_property(ring_finger, "scale:y", 0.75, 0.15)
		animation_tween.tween_property(ring_finger, "scale:y", 1.0, 0.1)
		animation_tween.parallel().tween_property(middle_finger, "scale:y", 0.75, 0.15)
		animation_tween.tween_property(middle_finger, "scale:y", 1.0, 0.1)
		animation_tween.parallel().tween_property(index_finger, "scale:y", 0.75, 0.15)
		animation_tween.tween_property(index_finger, "scale:y", 1.0, 0.1)
	elif not other_fingers.visible and animation_tween:
		#prints("kill")
		animation_tween.stop()
		animation_tween.kill()
		animation_tween = null
		pinky_finger.scale.y = 1.0
		ring_finger.scale.y = 1.0
		middle_finger.scale.y = 1.0
		index_finger.scale.y = 1.0


func _select_hovered_piece_under_cursor() -> void:
	#selects which piece under the cursor is the one currently hovered
	if pieces_under_cursor.is_empty():
		_unhover_piece()
		return
	
	if Game.piece_grabbed:
		_unhover_piece()
		return

	var closest : PieceGrabArea = pieces_under_cursor[0]
	var curr_dist : float = 999999.9
	#NOTE: it's important the grabber_area is positioned where we want
	#      the center point for grabbing to be!
	var grabber_pos : Vector2 = grabber_area.global_position
	for piece_area : PieceGrabArea in pieces_under_cursor:
		piece_area.piece.border_color = Color.BLACK
		for col_shape_pos : Vector2 in _get_col_shapes_pos(piece_area):
			var new_dist : float = grabber_pos.distance_to(col_shape_pos)
			if new_dist < curr_dist:
				curr_dist = new_dist
				closest = piece_area
	
	piece_hovered = closest.piece
	piece_hovered.border_color = Color.INDIGO


func _get_col_shapes_pos(piece_area : PieceGrabArea) -> Array[Vector2]:
	var shapes : Array[Vector2] = []
	for child : Node2D in piece_area.get_children():
		if child is not CollisionShape2D:
			continue
		if child.shape is not RectangleShape2D:
			continue
		var rect : RectangleShape2D = child.shape
		shapes.append(child.global_position + rect.size / 2)
	return shapes


func _unhover_piece() -> void:
	if not piece_hovered:
		return
	piece_hovered.border_color = Color.BLACK
	piece_hovered = null


func _on_grabber_area_area_entered(area: Area2D) -> void:
	if not (area is PieceGrabArea):
		return
	if pieces_under_cursor.has(area):
		return
	pieces_under_cursor.append(area)


func _on_grabber_area_area_exited(area: Area2D) -> void:
	if not (area is PieceGrabArea):
		return
	pieces_under_cursor.erase(area)
	area.piece.border_color = Color.BLACK
