extends TextureRect
class_name PreviewCells

const COLOR_OFF : Color = Color(0.388, 0.318, 0.259)
const COLOR_ON  : Color = Color.WHITE

@export var shape : Piece.SHAPE_KIND

func _process(_delta: float) -> void:
	var pv_cells := get_children()
	match shape:
		Piece.SHAPE_KIND.Z:
			pv_cells[0].modulate = COLOR_ON
			pv_cells[1].modulate = COLOR_ON
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_ON
			pv_cells[6].modulate = COLOR_OFF
			pv_cells[7].modulate = COLOR_OFF
			pv_cells[8].modulate = COLOR_OFF
		Piece.SHAPE_KIND.S:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_OFF
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_ON
			pv_cells[6].modulate = COLOR_ON
			pv_cells[7].modulate = COLOR_ON
			pv_cells[8].modulate = COLOR_OFF
		Piece.SHAPE_KIND.J:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_ON
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_OFF
			pv_cells[6].modulate = COLOR_ON
			pv_cells[7].modulate = COLOR_ON
			pv_cells[8].modulate = COLOR_OFF
		Piece.SHAPE_KIND.L:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_ON
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_OFF
			pv_cells[6].modulate = COLOR_OFF
			pv_cells[7].modulate = COLOR_ON
			pv_cells[8].modulate = COLOR_ON
		Piece.SHAPE_KIND.O:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_ON
			pv_cells[2].modulate = COLOR_ON
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_ON
			pv_cells[6].modulate = COLOR_OFF
			pv_cells[7].modulate = COLOR_OFF
			pv_cells[8].modulate = COLOR_OFF
		Piece.SHAPE_KIND.I:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_ON
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_OFF
			pv_cells[6].modulate = COLOR_OFF
			pv_cells[7].modulate = COLOR_ON
			pv_cells[8].modulate = COLOR_OFF
		Piece.SHAPE_KIND.T:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_OFF
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_ON
			pv_cells[5].modulate = COLOR_OFF
			pv_cells[6].modulate = COLOR_ON
			pv_cells[7].modulate = COLOR_ON
			pv_cells[8].modulate = COLOR_ON
		_:
			pv_cells[0].modulate = COLOR_OFF
			pv_cells[1].modulate = COLOR_OFF
			pv_cells[2].modulate = COLOR_OFF
			pv_cells[3].modulate = COLOR_OFF
			pv_cells[4].modulate = COLOR_OFF
			pv_cells[5].modulate = COLOR_OFF
			pv_cells[6].modulate = COLOR_OFF
			pv_cells[7].modulate = COLOR_OFF
			pv_cells[8].modulate = COLOR_OFF
	
