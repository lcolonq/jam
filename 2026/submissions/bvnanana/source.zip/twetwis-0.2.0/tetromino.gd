extends Node2D
class_name Tetromino

var col_shape_template : PackedScene = preload("res://shape_col_template.tscn")
var particles_piece_scene := preload("res://particles_piece.tscn")

@export var piece : Piece

@onready var line_body: Line2D = %line_body
@onready var head: Sprite2D = %head
@onready var eyes: Node2D = %eyes
@onready var eyes_base: Node2D = %eyes_base
@onready var eyes_wide: Node2D = %eyes_wide
@onready var grab_area: Area2D = %grab_area
@onready var eye_l: Sprite2D = %eye_l
@onready var eye_r: Sprite2D = %eye_r

@onready var mouth : Line2D = %mouth
@onready var mouth_open1 : Line2D = %mouth_open1
@onready var mouth_open2 : Line2D = %mouth_open2

var line_anchors : PackedVector2Array = []
var line_anchors_prev : PackedVector2Array = []
var line_offsets : PackedVector2Array = []

var wiggle_tween : Tween

var should_place_particles : bool = false
var head_scale_base : Vector2 = Vector2.ONE

var rotate_tween : Tween
var rotate_prev_rotations : int = 0

var blink_tween : Tween

#region grab
var line_col_shapes : Array[CollisionShape2D] = []

var grabbed_offset : Vector2 = Vector2.ZERO
var grabbed_head_offset : Vector2 = Vector2.ZERO
var grabbed_head_offset_target : Vector2 = Vector2.ZERO
#endregion


func _ready() -> void:
	assert(piece != null)

	piece.landed.connect(talk)
	piece.grabbed.connect(talk.bind(0.8))
	piece.ungrabbed.connect(talk)
	

	var total_blocks : int = piece.shape.blocks.size()
	line_body.points = PackedVector2Array(piece.shape.blocks)

	line_anchors.resize(total_blocks)
	line_anchors_prev.resize(total_blocks)
	line_offsets.resize(total_blocks)

	line_anchors.fill(Vector2.ZERO)
	line_anchors_prev.fill(Vector2.ZERO)
	line_offsets.fill(Vector2.ZERO)
	
	if randf() > 0.5:
		head_scale_base = Vector2(-1, 1)
	
	_start_wiggling()
	_start_blinking()
	_anchor_to_cell()
	_move_line_points()
	_move_head()
	_init_grab_area()
	_adjust_grab_area()
	
	#not ideal but we need to do it only for "base" pieces
	if piece.shape.blocks.size() == 4:
		Sounds.play(Sounds.POP, 0.5)
		modulate.a = 0.0
		var alpha_tween : Tween = get_tree().create_tween()
		alpha_tween.tween_property(self, "modulate:a", 1.0, 0.15)
		alpha_tween.tween_callback(talk)


func _process(delta: float) -> void:
	_anchor_to_cell()
	_move_line_points()
	_move_head()
	_adjust_grab_area()
	
	if piece.is_grabbed:
		var lerp_speed := delta * 100.0
		grabbed_offset = grabbed_offset.move_toward(
			Grid.CELL_SIZE * Vector2(0, -0.5), lerp_speed)
		line_body.width = move_toward(line_body.width, 16.0 * 1.25, lerp_speed)
		head.scale      = head.scale.move_toward(head_scale_base * 1.4, lerp_speed)
		eyes.scale      = eyes.scale.move_toward(Vector2.ONE / 1.4, lerp_speed)
		piece.z_index   = move_toward(piece.shadow_size, 2.0, lerp_speed) as int
		piece.shadow_size   = move_toward(piece.shadow_size, 6.0, lerp_speed)
		grabbed_head_offset = grabbed_head_offset.lerp(grabbed_head_offset_target, delta * 5)
		
		eyes_base.visible = false
		eyes_wide.visible = true
		should_place_particles = true
	else:
		var lerp_speed := delta * 50.0
		grabbed_offset = grabbed_offset.move_toward(Vector2.ZERO, lerp_speed)
		line_body.width = move_toward(line_body.width, 16.0, lerp_speed)
		head.scale      = head.scale.move_toward(head_scale_base, lerp_speed)
		eyes.scale      = eyes.scale.move_toward(Vector2.ONE, lerp_speed)
		piece.z_index   = move_toward(piece.shadow_size, 0.0, lerp_speed) as int
		piece.shadow_size   = move_toward(piece.shadow_size, 0.0, lerp_speed)
		grabbed_head_offset = Vector2.ZERO
		
		eyes_base.visible = true
		eyes_wide.visible = false
		
		if should_place_particles:
			spawn_particles()
			should_place_particles = false

	#rotate animation
	if rotate_prev_rotations != piece.clockwise_rotations:
		rotate_prev_rotations = piece.clockwise_rotations
		_animate_rotation()


func _animate_rotation() -> void:
	if rotate_tween:
		rotate_tween.kill()

	if not is_inside_tree(): return

	rotate_tween = get_tree().create_tween()
	rotate_tween.set_parallel(true)
	rotate_tween.set_ease(Tween.EASE_OUT)
	rotate_tween.set_trans(Tween.TRANS_BACK)

	for i : int in line_anchors_prev.size():
		var local_pos_prev : Vector2 = line_body.to_local(line_anchors_prev[i])
		var local_pos : Vector2 = line_body.to_local(line_anchors[i])
		var offset : Vector2 = line_offsets[i]
		head.visible = false
		rotate_tween.tween_method(
			func(new_val : Vector2) -> void:
				if line_body: line_body.set_point_position(i, new_val),
			local_pos_prev + offset + piece._next_cell_offset + grabbed_offset,
			local_pos      + offset + piece._next_cell_offset + grabbed_offset,
			Game.ROTATE_TIME
		)
	rotate_tween.tween_callback(func(): head.visible = true).set_delay(Game.ROTATE_TIME * .5)


func spawn_particles() -> void:
	for pos : Vector2 in line_anchors:
		var particles : GPUParticles2D = particles_piece_scene.instantiate()
		particles.global_position = pos
		#particles.global_position = piece.cell.global_position
		#particles.global_position += piece.cell.get_combined_pivot_offset()
		particles.amount = randi_range(1, 2)
		particles.emitting = true
		particles.one_shot = true
		particles.lifetime = randf_range(.3, .4)
		particles.finished.connect(particles.queue_free)
		add_child(particles)


#TODO: this function seems to take a long time the first time it's called in the game
func _start_blinking() -> void:
	if piece.shape.blocks.size() <= 0: return
	var delay : float = randf_range(1.0, 2.5)
	var speed : float = randf_range(0.1, 0.25)
	
	if blink_tween: blink_tween.kill()
	blink_tween = get_tree().create_tween()
	blink_tween.set_loops()
	blink_tween.set_parallel(true)
	#close eyes
	blink_tween.tween_property(
		eye_l, "region_rect", Rect2(0, 4, 4, 0), speed
	).set_delay(delay).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CIRC)
	blink_tween.tween_property(
		eye_r, "region_rect", Rect2(0, 4, 4, 0), speed
	).set_delay(delay).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CIRC)
	#open eyes
	blink_tween.tween_property(
		eye_l, "region_rect", Rect2(0, 0, 4, 4), speed
	).set_delay(delay + speed).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUART)
	blink_tween.tween_property(
		eye_r, "region_rect", Rect2(0, 0, 4, 4), speed
	).set_delay(delay + speed).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUART)


func _start_wiggling() -> void:
	if piece.shape.blocks.size() <= 0: return
	while is_inside_tree():
		if wiggle_tween: wiggle_tween.kill()
		wiggle_tween = get_tree().create_tween()
		for i : int in line_offsets.size():
			var angle := Vector2.from_angle(randf_range(0.0, TAU))
			var from  := Vector3(line_offsets[i].x, line_offsets[i].y, i)
			var to    := Vector3(angle.x, angle.y, i)
			wiggle_tween.tween_method(
				_wiggle_point, from, to,
				randf_range(0.05, 0.25) / piece.shape.blocks.size()
			)
		await wiggle_tween.finished


func _wiggle_point(index_and_offset : Vector3) -> void:
	var index : int = index_and_offset.z as int
	var offset : Vector2 = Vector2(index_and_offset.x, index_and_offset.y)
	line_offsets.set(index, offset)


func _anchor_to_cell() -> void:
	line_body.closed   = piece.shape.closed_loop
	for i : int in piece.shape.blocks.size():
		var block_offset   : Vector2i = piece.shape.blocks[i]
		var block_cell_pos : Vector2i = piece.cell.grid_pos + block_offset
		var block_cell     : Cell     = Grid.get_cell_at(block_cell_pos)
		line_anchors[i] = block_cell.global_position
		line_anchors[i] += block_cell.get_combined_pivot_offset() #center in cell
	
	#NOTE: this has to be done like this because calling get_cell_at with the previous blocks 
	#      can lead to querying for a cell outside the grid.
	for i : int in piece._prev_blocks.size():
		var block_offset   : Vector2 = piece._prev_blocks[i] as Vector2
		line_anchors_prev[i] = piece.cell.global_position
		line_anchors_prev[i] += Grid.CELL_SIZE * block_offset
		line_anchors_prev[i] += Grid.CELL_SIZE / 2


func _move_line_points() -> void:
	for i : int in line_anchors.size():
		var local_pos : Vector2 = line_body.to_local(line_anchors[i])
		var offset : Vector2 = line_offsets[i]
		var new_pos := local_pos + offset + piece._next_cell_offset + grabbed_offset
		line_body.set_point_position(i, new_pos)


func _move_head() -> void:
	#head target offset
	if piece.is_grabbed:
		grabbed_head_offset_target = get_global_mouse_position() - head.global_position
		grabbed_head_offset_target = grabbed_head_offset_target.clamp(
			Grid.CELL_SIZE * Vector2(-0.5, -0.25),
			Grid.CELL_SIZE * Vector2(+0.5, +0.25)
		)
	
	#head movement
	var new_pos := line_anchors[piece.shape.head_index]
	new_pos += line_offsets[piece.shape.head_index]
	new_pos += piece._next_cell_offset + grabbed_offset + grabbed_head_offset
	head.global_position = new_pos
	

func _init_grab_area() -> void:
	line_col_shapes.clear()

	#clear in case there's trash in the grab area!
	for grab_area_child : Node in grab_area.get_children():
		grab_area_child.queue_free()

	var cell_pixel_size : Vector2 = Grid.CELL_SIZE
	for i in line_anchors.size():
		var col_shape := col_shape_template.instantiate()
		col_shape.shape.size = cell_pixel_size
		line_col_shapes.append(col_shape)
		grab_area.add_child(col_shape)


func _adjust_grab_area() -> void:
	for i : int in line_anchors.size():
		var pos : Vector2 = line_anchors[i]
		line_col_shapes[i].position = pos


func talk(chance : float = 0.2) -> void:
	if Game.gravity_paused: return
	if piece.shape.blocks.size() <= 1: return # 1 block pieces cannot talk
	if randf() < 1.0 - chance: return
	for i : int in randi_range(1, 3):
		#animate the mouth
		var mouth_shape : float = randf()
		if mouth_shape > 0.6 or i == 0: #makes sure to always open mouth at first
			mouth_open1.visible = true
		elif mouth_shape > 0.3:
			mouth_open2.visible = true
		
		mouth.rotation = deg_to_rad(randf_range(-12, 0))

		#play the sounds
		var player := AudioStreamPlayer2D.new()
		player.global_position = piece.cell.global_position
		player.stream = Sounds.VOICE.pick_random()
		player.autoplay = true
		if piece.shape_base_kind == Piece.SHAPE_KIND.O:
			player.pitch_scale = randf_range(1.2, 1.8)
		else:
			player.pitch_scale = randf_range(2.0, 3.0)
		player.volume_db = linear_to_db(0.3)
		player.finished.connect(func(): player.queue_free())
		add_child(player)

		await player.finished
	
		mouth_open1.visible = false
		mouth_open2.visible = false
		mouth.rotation = deg_to_rad(0.0)


func _exit_tree() -> void:
	if blink_tween: blink_tween.kill()
