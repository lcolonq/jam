extends CanvasGroup
class_name Piece

signal landed()
signal grabbed()
signal ungrabbed()

#region gravity
var gravity_timer : Timer = Timer.new()
var gravity_speed : float = 0.15
#endregion

#region defs

const TOP_LEFT     := Vector2i(-1, -1)
const TOP          := Vector2i( 0, -1)
const TOP_RIGHT    := Vector2i( 1, -1)
const LEFT         := Vector2i(-1,  0)
const CENTER       := Vector2i( 0,  0)
const RIGHT        := Vector2i( 1,  0)
const BOTTOM_LEFT  := Vector2i(-1,  1)
const BOTTOM       := Vector2i( 0,  1)
const BOTTOM_RIGHT := Vector2i( 1,  1)

enum SHAPE_KIND {Z, S, J, L, O, I, T}

class Shape:
	var blocks : Array[Vector2i] = []
	var closed_loop : bool = false
	var head_index : int = 0
	func _init(
		_blocks : Array[Vector2i],
		_closed_loop : bool = false,
		_head_index : int = 0,
	) -> void:
		self.blocks = _blocks
		self.closed_loop = _closed_loop
		self.head_index = _head_index
	

static var BaseShapes : Dictionary[SHAPE_KIND, Shape] = {
	SHAPE_KIND.Z: Shape.new([RIGHT, CENTER, TOP, TOP_LEFT]),
	SHAPE_KIND.S: Shape.new([LEFT, CENTER, TOP, TOP_RIGHT]),
	SHAPE_KIND.J: Shape.new([TOP_LEFT, LEFT, CENTER, RIGHT]),
	SHAPE_KIND.L: Shape.new([LEFT, CENTER, RIGHT, TOP_RIGHT]),
	SHAPE_KIND.O: Shape.new([CENTER, TOP, TOP_LEFT, LEFT], true),
	SHAPE_KIND.I: Shape.new([LEFT, CENTER, RIGHT, Vector2(2, 0)]),
	SHAPE_KIND.T: Shape.new([TOP, CENTER, RIGHT, LEFT]),
}

#endregion


#region shape and cell
var cell : Cell
var shape : Shape
var shape_base_kind : Piece.SHAPE_KIND
#endregion

var shadow_size : float = 0.0
var border_color : Color = Color.BLACK
var is_destructable : bool = true
var is_grabbed : bool = false : set = _set_is_grabbed
var clockwise_rotations : int = 0
var _prev_blocks : Array[Vector2i] = []

var move_direction : Vector2i = Vector2i.ZERO
# smooth transition towards next cell
var _next_cell : Cell = null
var _next_cell_offset : Vector2 = Vector2.ZERO

func _set_is_grabbed(new_val : bool) -> void:
	if new_val == is_grabbed: return
	if new_val:
		grabbed.emit()
	else:
		ungrabbed.emit()
	is_grabbed = new_val

func can_animate_to(new_cell : Cell) -> bool:
	var occupied_positions := Game.get_occupied_cells()
	var piece_positions    := get_all_positions()
	
	for offset : Vector2i in shape.blocks:
		var new_pos := new_cell.grid_pos + offset
		if not Grid.cell_exists(new_pos):
			return false
		
	 	#ignore positions we own
		if piece_positions.has(new_pos):
			continue
		
		if occupied_positions.has(new_pos):
			#if Game.is_piece_grabbed_in_cell(new_pos):
				#return false
			if not Game.is_piece_in_cell_moving(new_pos):
				return false

	return true


## this checks if a new set of blocks will be valid, used for example before rotation
func can_place_blocks(blocks : Array[Vector2i], grid_pos : Vector2i) -> bool:
	var occupied_positions := Game.get_occupied_cells()
	var piece_positions    := get_all_positions()
	for offset : Vector2i in blocks:
		var new_pos := grid_pos + offset
		if not Grid.cell_exists(new_pos):
			#prints("CELL NOT EXIST!", new_pos)
			return false

		#ignore positions we own
		if piece_positions.has(new_pos):
			continue
		
		if occupied_positions.has(new_pos):
			#prints("CELL OCCUPIED!", new_pos, occupied_positions, piece_positions)
			return false
	return true


func can_spawn() -> bool:
	var occupied_positions := Game.get_occupied_cells()
	for piece_position : Vector2i in get_all_positions():
		if occupied_positions.has(piece_position):
			return false
	return true


func get_all_positions() -> Array[Vector2i]:
	return get_all_positions_from(cell.grid_pos, shape.blocks)


static func get_all_positions_from(
	grid_pos : Vector2i,
	blocks : Array[Vector2i]
) -> Array[Vector2i]:
	var result : Array[Vector2i] = []
	for offset : Vector2i in blocks:
		result.append(grid_pos + offset)
	return result


func init_from_base_shape_kind(shape_kind : SHAPE_KIND, cell_origin : Cell) -> void:
	self.shape_base_kind = shape_kind
	self.cell = cell_origin
	self.shape = Shape.new(
		BaseShapes[shape_kind].blocks,
		BaseShapes[shape_kind].closed_loop,
		randi_range(0, BaseShapes[shape_kind].blocks.size() - 1)
	)
	


func _ready() -> void:
	assert(is_instance_valid(cell), "cell must be a valid instance, call init() first!")
	assert(shape != null, "shape missing, call init() first!")
	
	gravity_timer.autostart = true
	gravity_timer.wait_time = gravity_speed
	gravity_timer.timeout.connect(_apply_gravity)
	add_child(gravity_timer)


func _process(delta: float) -> void:
	gravity_timer.paused = Game.gravity_paused

	process_movement()
	update_next_cell()

	if _next_cell:
		var target_offset := _next_cell.global_position - cell.global_position
		_next_cell_offset = _next_cell_offset.lerp(
			target_offset,
			1.0 / gravity_timer.time_left * delta
		).clamp(Vector2.ZERO, target_offset)
	
	self_modulate = border_color
	self_modulate.a = shadow_size


func _apply_gravity() -> void:
	var cell_below_pos : Vector2i = cell.grid_pos + Piece.BOTTOM
	if not Grid.cell_exists(cell_below_pos):
		return
	move_direction.y += 1


func update_next_cell() -> void:
	var next_cell_pos : Vector2i = cell.grid_pos + Piece.BOTTOM
	if Grid.cell_exists(next_cell_pos):
		var next_cell : Cell = Grid.get_cell_at(next_cell_pos) 
		if can_animate_to(next_cell):
			if _next_cell != next_cell:
				_next_cell = next_cell
				_next_cell_offset = Vector2i.ZERO
			return

	if not _next_cell: return
	_next_cell = null
	_next_cell_offset = Vector2i.ZERO
	Game.particles_place.spawn_at(
		cell.global_position + cell.get_combined_pivot_offset()
	)
	
	if is_destructable:
		Sounds.play(Sounds.LAND, randf_range(1.0, 1.5), linear_to_db(0.3))
	else:
		Sounds.play(Sounds.LAND_INDESTRUCTIBLE, randf_range(1.0, 1.5))
		Game.screen_shake(1)
	landed.emit()


func process_movement() -> void:
	if move_direction == Vector2i.ZERO: return

	var dir_sign    : Vector2i = move_direction.sign()
	var dir_allowed : Vector2i = Vector2i.ZERO
	var curr_pos    : Vector2i = cell.grid_pos

	#NOTE: vertical movement has checking priority! so we first check for y ONLY
	for i : int in range(abs(move_direction.y)):
		var target_pos := curr_pos + Vector2i(0, i * dir_sign.y)
		if not Grid.cell_exists(target_pos): break
		if not can_place_blocks(shape.blocks, target_pos): break
		dir_allowed.y += dir_sign.y
	
	#now we check for x
	for i : int in range(abs(move_direction.x)):
		var target_pos := curr_pos + dir_allowed + Vector2i(i * dir_sign.x, 0)
		if not Grid.cell_exists(target_pos): break
		if not can_place_blocks(shape.blocks, target_pos): break
		dir_allowed.x += dir_sign.x
	
	var target_cell_pos : Vector2i = cell.grid_pos + dir_allowed
	#prints("dir allowed", dir_allowed, target_cell_pos)
	if Grid.cell_exists(target_cell_pos):
		#prints("cell exists", target_cell_pos)
		var target_cell : Cell = Grid.get_cell_at(target_cell_pos)
		if can_place_blocks(shape.blocks, target_cell.grid_pos):
			#prints("updated cell")
			cell = target_cell
			if dir_allowed.x != 0:
				Sounds.play(Sounds.MOVE, randf_range(1.0, 1.2), linear_to_db(0.3))

	move_direction = Vector2i.ZERO

	
func rotate_clockwise() -> void:
	if shape.blocks.size() <= 1: return
	const wall_kicks : Array[Vector2i] = [CENTER, LEFT, RIGHT, TOP, BOTTOM]
	var rotated_blocks := _rotated_blocks()
	for wall_kick : Vector2i in wall_kicks:
		var target_cell_pos := cell.grid_pos + wall_kick
		if can_place_blocks(rotated_blocks, target_cell_pos):
			_prev_blocks = shape.blocks
			shape.blocks = rotated_blocks
			cell = Grid.get_cell_at(target_cell_pos)
			clockwise_rotations += 1
			#prints("rotated wall kick:", wall_kick)
			return
	#prints("COULD NOT ROTATE!")


func _rotated_blocks() -> Array[Vector2i]:
	var rotated_blocks : Array[Vector2i] = []
	for block : Vector2i in shape.blocks:
		var block_vec2 : Vector2 = Vector2(block)
		var block_rotated := block_vec2.orthogonal().orthogonal().orthogonal()
		rotated_blocks.append(block_rotated as Vector2i)
	return rotated_blocks


func get_neighboring_positions() -> Array[Vector2i]:
	var valid_pos : Array[Vector2i] = []
	var block_positions : Array[Vector2i] = get_all_positions()
	var neighbors : Array[Vector2i] = [LEFT, RIGHT, BOTTOM, TOP]
	for block : Vector2i in shape.blocks:
		var block_pos : Vector2i = cell.grid_pos + block
		for neighbor : Vector2i in neighbors:
			var pos : Vector2i = block_pos + neighbor
			if valid_pos.has(pos):        continue
			if block_positions.has(pos):  continue #dont count self as neighbor
			if not Grid.cell_exists(pos): continue
			valid_pos.append(pos)
	return valid_pos
