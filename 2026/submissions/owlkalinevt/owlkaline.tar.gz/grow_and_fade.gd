extends TextureRect

@export var accepted_text: Texture2D;

var accepted = false;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if accepted:
		texture = accepted_text;
	
	scale.x = 0.7 + randf() *0.2;
	scale.y = scale.x;
	position.x = min(max(randf()*260, 0.0), 260-size.x*1.1);
	position.y = min(max(randf()*140, size.y*0.5), 140-size.y*0.5);
	modulate.a = 1.0;
	var tween = create_tween();
	tween.tween_property(self, "modulate:a", 0.0, 2.0);
	tween.tween_property(self, "scale:x", 1.0, 2.0);
	tween.tween_property(self, "scale:y", 1.0, 2.0);
	add_child(tween);

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
