extends Node

var jobs = [
"Accountant",
"Actor/Actress",
"Architect",
"Astronomer",
"Baker",
"Bricklayer",
"Bus driver",
"Butcher",
"Carpenter",
"Chef/Cook",
"Cleaner",
"Dentist",
"Designer",
"Doctor",
"Electrician",
"Engineer",
"Factory worker",
"Farmer",
"Fireman/Firefighter",
"Fisherman",
"Florist",
"Gardener",
"Hairdresser",
"Journalist",
"Judge",
"Lawyer",
"Lecturer",
"Librarian",
"Lifeguard",
"Mechanic",
"Model",
"Newsreader",
"Nurse",
"Optician",
"Painter",
"Pharmacist",
"Photographer",
"Pilot",
"Plumber",
"Politician",
"Policeman/Policewoman",
"Postman",
"Real estate agent",
"Receptionist",
"Scientist",
"Secretary",
"Shop assistant",
"Software developer",
"Game Developer",
"Tailor",
"Taxi driver",
"Teacher",
"Translator",
"Traffic warden",
"Travel agent",
"Veterinary doctor (Vet)",
"Waiter/Waitress",
"Businessman",
"Dancer",
"Artist",
"Bartender"
]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
