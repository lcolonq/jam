extends Node2D

var rejects_this_week = 0;
var offers_this_week = 0;

var did_get_accepted = false;

@export var rejcted: PackedScene
@export var timer: Timer
@export var finished_timer: Timer
@export var no_responses_text: Label

signal finished(got_an_offer: bool);

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	visibility_changed.connect(execute_animation);
	timer.timeout.connect(show_result);
	finished_timer.timeout.connect(response_screen_finished);

func response_screen_finished():
	hide();
	finished.emit(did_get_accepted);
	

func execute_animation():
	if !visible:
		return;
	
	# do stuff
	if offers_this_week + rejects_this_week == 0:
		finished_timer.start();
		no_responses_text.show();
	else:
		no_responses_text.hide();
		timer.start();

func show_result():
	timer.wait_time = randf()*0.3 + 0.2;
	
	var r = rejcted.instantiate();
	
	if offers_this_week > 0 and (
			(rejects_this_week > 0 and randf() < 0.3) 
		or 
			(rejects_this_week <= 0)
		):
		r.accepted = true;
		offers_this_week -= 1;
		did_get_accepted = true;
	else:
		rejects_this_week -= 1;
	
	add_child(r);
	if rejects_this_week > 0 or offers_this_week > 0:
		timer.start();
	else:
		finished_timer.start();

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
