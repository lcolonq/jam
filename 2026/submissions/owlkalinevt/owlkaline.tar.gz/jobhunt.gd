class_name JobHunting extends Control

signal game_over(win: bool);

var weeks_left = 4;
var energy = 100;

var jobs_applied_for = 0;
var rejections = 0;
var job_offers = 0;

var rejections_this_week = 0;
var job_offers_this_week = 0;

var awaiting_jobs: Dictionary[int, Array] = {};

@export var job_apply_screen: Control
@export var response_screen: Node2D

@export var apply: Button
@export var ooe: Label
@export var job_name: Label

@export var wait_till_next_week: Button
@export var effort_to_use: HSlider
@export var weeks_left_number: Label
@export var total_energy: TextureProgressBar
@export var popup_panel: PopupPanel
@export var see_responses: Button

@export var waiting_for_response_text: Label
@export var jobs_applied_for_text: Label
@export var responses_text: Label

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	wait_till_next_week.pressed.connect(progress_week)
	apply.pressed.connect(apply_for_job)
	see_responses.pressed.connect(see_response);
	response_screen.finished.connect(new_week);
	update_energy();
	job_name.text = JobNames.jobs.pick_random();

func start_game():
	job_apply_screen.show();

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func apply_for_job():
	# 0 - 1
	# -0.5 - 0.5
	#abs( -1.0 - 1.0)   < 0.5 = middle
	# +0.5 then < 1.0 and max is 1.5 what we want to make bigger
	#1.0 -  1.5 - 0.5 = 1.0
	# 0.5 - 0.5 = 0.0
	# (1.0 - (abs((v-0.5)*2.0) + 0.5)) * extra_energy
	var extra_energy = 20.0;
	var mid_effort_debuff = max(0.0, (1.0 - (abs((effort_to_use.value*0.01-0.5)*2.0) + 0.5))) * extra_energy;
	var energy_used = floor(max(5.0, mid_effort_debuff + effort_to_use.value * 0.75 * randf()));
	
	if energy_used > energy:
		# make a popup
		energy = 0;
		apply.hide();
		ooe.show();
		pass;
	
	awaiting_jobs.get_or_add(weeks_left, []).append(effort_to_use.value);
	jobs_applied_for += 1;
	energy -= energy_used;
	update_energy();
	job_name.text = JobNames.jobs.pick_random();

func progress_week():
	job_offers_this_week = 0;
	rejections_this_week = 0;
	
	var jobs_applied_for_this_week = awaiting_jobs.get_or_add(weeks_left, []).size();
	
	for in_week in awaiting_jobs:
		var distance_in_weeks = in_week - weeks_left;
		for effort_used in awaiting_jobs[in_week]:
			var base_response_chance = (1.0+distance_in_weeks) * 15.0;
			base_response_chance *= (1.0 + (effort_used / 50.0));
		
			if randi() % 100 < base_response_chance:
				# They respond
				# - reject or pass
				awaiting_jobs[in_week].erase(effort_used);
				
				var early_response_buff = 25.0 - distance_in_weeks*10.0;
				var pass_chance = 3.0 + 5.0 * (effort_used/17.0);
				
				if randi() % 100 < pass_chance:
					job_offers += 1;
					job_offers_this_week += 1;
				else:
					rejections += 1;
					rejections_this_week += 1;
		
	
	weeks_left -= 1;
	energy = 100;
	weeks_left_number.text = str(weeks_left);
	waiting_for_response_text.text = str(jobs_applied_for - rejections - job_offers);
	jobs_applied_for_text.text = str(jobs_applied_for_this_week)
	responses_text.text = str(job_offers_this_week + rejections_this_week);
	update_energy();
	job_apply_screen.hide();
	popup_panel.show();

func update_energy():
	#total_energy_number.text = str(energy) + "%";
	total_energy.value = energy;

func see_response():
	job_apply_screen.hide();
	popup_panel.hide();
	response_screen.rejects_this_week = rejections_this_week;
	response_screen.offers_this_week = job_offers_this_week;
	response_screen.show();

func new_week(success: bool):
	response_screen.hide();
	popup_panel.hide();
	job_apply_screen.show();
	ooe.hide();
	apply.show();
	
	job_name.text = JobNames.jobs.pick_random();
	job_name.show();
	
	if success:
		game_over.emit(true);
		job_apply_screen.hide();
	elif weeks_left < 0:
		game_over.emit(false);
		job_apply_screen.hide();
	

	
