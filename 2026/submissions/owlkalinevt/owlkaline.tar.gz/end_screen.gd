extends Control

@export var job_hunting: JobHunting
@export var win_text: Label
@export var lose_text: Label

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	job_hunting.game_over.connect(game_over);

func game_over(win: bool):
	if win:
		win_text.show();
	else:
		lose_text.show();

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
