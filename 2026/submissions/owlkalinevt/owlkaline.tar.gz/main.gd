extends Control

@export var job_hunting: JobHunting

@export var job_hunting_scene: PackedScene

var started = false;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# start_new_game()
	JavaScriptBridge.eval("window.parent.postMessage({op: \"ready\"});");
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	var difficulty: float = JavaScriptBridge.eval("window.lcolonqJamStart || -1.0");
	if !started && difficulty > 0.0:
		started = true
		start_new_game();
		JavaScriptBridge.eval("window.parent.postMessage({op: \"started\"});")

func start_new_game():
	if job_hunting != null:
		remove_child(job_hunting);
	job_hunting = job_hunting_scene.instantiate();
	job_hunting.game_over.connect(game_over);
	add_child(job_hunting);
	job_hunting.start_game();

func game_over(win: bool):
	if win:
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: true});")
	else:
		JavaScriptBridge.eval("window.parent.postMessage({op: \"done\", win: false});")
	get_tree().reload_current_scene()
