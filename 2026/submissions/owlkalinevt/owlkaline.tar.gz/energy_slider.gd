extends VBoxContainer

@export var effort_to_use: HSlider
@export var effort_percent: Label

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	effort_to_use.value_changed.connect(update_percentage);
	update_percentage(effort_to_use.value);

func update_percentage(value: float):
	effort_percent.text = str(int(value)) + "%";

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
